import { useState, useEffect } from "react";
import { formatBytes, FileItem } from "@/lib/mock-data";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { HardDrive, Archive, Trash2, Clock } from "lucide-react";
import { motion } from "framer-motion";

interface StatsCardsProps {
  files: FileItem[];
  selectedCount: number;
}

export function StatsCards({ files, selectedCount }: StatsCardsProps) {
  const totalSize = files.reduce((acc, file) => acc + file.size, 0);
  const totalFiles = files.length;
  
  // Find oldest file date
  const oldestFile = files.reduce((oldest, file) => {
    return file.lastModified < oldest.lastModified ? file : oldest;
  }, files[0] || { lastModified: new Date() });

  const stats = [
    {
      title: "Total Reclaimable",
      value: formatBytes(totalSize),
      icon: HardDrive,
      color: "text-blue-500",
      desc: `${totalFiles} files found`
    },
    {
      title: "Oldest File",
      value: oldestFile ? Math.floor((new Date().getTime() - oldestFile.lastModified.getTime()) / (1000 * 60 * 60 * 24)) + " days" : "0 days",
      icon: Clock,
      color: "text-orange-500",
      desc: "Since last modification"
    },
    {
      title: "Selected",
      value: selectedCount.toString(),
      icon: Archive,
      color: "text-purple-500",
      desc: "Ready for action"
    }
  ];

  return (
    <div className="grid gap-4 md:grid-cols-3 mb-6">
      {stats.map((stat, i) => (
        <motion.div
          key={stat.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.1 }}
        >
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {stat.title}
              </CardTitle>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground">
                {stat.desc}
              </p>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}
