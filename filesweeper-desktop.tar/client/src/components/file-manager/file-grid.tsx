import { FileItem, formatBytes } from "@/lib/mock-data";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { FileIcon, ImageIcon, VideoIcon, MusicIcon, FileTextIcon, ArchiveIcon, Info, Eye, ExternalLink, Calendar, HardDrive, Clock, Download, Copy, Check } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

interface FileGridProps {
  files: FileItem[];
  selectedIds: string[];
  onToggleSelect: (id: string) => void;
  viewMode?: 'grid' | 'list';
}

const FileTypeIcon = ({ type }: { type: string }) => {
  switch (type) {
    case "image": return <ImageIcon className="h-8 w-8 text-blue-500" />;
    case "video": return <VideoIcon className="h-8 w-8 text-purple-500" />;
    case "audio": return <MusicIcon className="h-8 w-8 text-pink-500" />;
    case "document": return <FileTextIcon className="h-8 w-8 text-orange-500" />;
    case "archive": return <ArchiveIcon className="h-8 w-8 text-yellow-500" />;
    default: return <FileIcon className="h-8 w-8 text-gray-500" />;
  }
};

const FileTypeIconSmall = ({ type }: { type: string }) => {
  switch (type) {
    case "image": return <ImageIcon className="h-4 w-4 text-blue-500" />;
    case "video": return <VideoIcon className="h-4 w-4 text-purple-500" />;
    case "audio": return <MusicIcon className="h-4 w-4 text-pink-500" />;
    case "document": return <FileTextIcon className="h-4 w-4 text-orange-500" />;
    case "archive": return <ArchiveIcon className="h-4 w-4 text-yellow-500" />;
    default: return <FileIcon className="h-4 w-4 text-gray-500" />;
  }
};

export function FileGrid({ files, selectedIds, onToggleSelect, viewMode = 'grid' }: FileGridProps) {
  const { toast } = useToast();
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const copyPath = async (path: string, fileId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(path);
      setCopiedId(fileId);
      toast({
        title: "Path Copied",
        description: "File path copied to clipboard",
      });
      setTimeout(() => setCopiedId(null), 2000);
    } catch (err) {
      toast({
        title: "Copy Failed",
        description: "Could not copy path to clipboard",
        variant: "destructive",
      });
    }
  };

  if (files.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-center border-2 border-dashed rounded-lg">
        <div className="p-4 rounded-full bg-muted mb-3">
          <FileIcon className="h-8 w-8 text-muted-foreground" />
        </div>
        <h3 className="text-lg font-medium">No files found</h3>
        <p className="text-sm text-muted-foreground mt-1">Try adjusting your filters</p>
      </div>
    );
  }

  if (viewMode === 'list') {
    return (
      <div className="flex flex-col gap-2 pb-20">
        <div className="grid grid-cols-[auto,1fr,100px,100px,120px,auto] gap-4 px-4 py-2 text-xs font-medium text-muted-foreground border-b">
          <div className="w-5"></div>
          <div>Name</div>
          <div>Size</div>
          <div>Type</div>
          <div>Modified</div>
          <div className="w-16">Actions</div>
        </div>
        <AnimatePresence mode="popLayout">
          {files.map((file) => (
            <motion.div
              layout
              key={file.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.15 }}
            >
              <Dialog>
                <div 
                  className={`group grid grid-cols-[auto,1fr,100px,100px,120px,auto] gap-4 items-center px-4 py-3 rounded-lg cursor-pointer transition-all duration-200 hover:bg-muted/50 border-2 ${
                    selectedIds.includes(file.id) ? "border-primary bg-primary/5" : "border-transparent"
                  }`}
                  onClick={() => onToggleSelect(file.id)}
                >
                  <Checkbox 
                    checked={selectedIds.includes(file.id)} 
                    onCheckedChange={() => onToggleSelect(file.id)}
                    onClick={(e) => e.stopPropagation()}
                  />
                  
                  <div className="flex items-center gap-3 min-w-0">
                    <FileTypeIconSmall type={file.type} />
                    <div className="min-w-0">
                      <p className="font-medium truncate text-sm" title={file.name}>{file.name}</p>
                      <p className="text-xs text-muted-foreground truncate" title={file.path}>{file.path}</p>
                    </div>
                  </div>
                  
                  <span className="text-sm font-mono">{formatBytes(file.size)}</span>
                  
                  <Badge variant="secondary" className="font-mono text-[10px] w-fit">
                    {file.extension.toUpperCase()}
                  </Badge>
                  
                  <span className="text-xs text-muted-foreground">{format(file.lastModified, 'MMM d, yyyy')}</span>
                  
                  <div className="flex items-center gap-1">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={(e) => copyPath(file.path, file.id, e)}
                      title="Copy path"
                      data-testid={`button-copy-path-list-${file.id}`}
                    >
                      {copiedId === file.id ? <Check className="h-3.5 w-3.5 text-green-500" /> : <Copy className="h-3.5 w-3.5" />}
                    </Button>
                    <DialogTrigger asChild onClick={(e) => e.stopPropagation()}>
                      <Button variant="ghost" size="icon" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity" title="View details">
                        <Eye className="h-3.5 w-3.5" />
                      </Button>
                    </DialogTrigger>
                  </div>
                </div>

                <DialogContent className="sm:max-w-[425px]">
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                      <FileTypeIcon type={file.type} />
                      <span className="truncate">{file.name}</span>
                    </DialogTitle>
                    <DialogDescription>
                      File details and metadata
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="mt-4 space-y-4">
                    {file.type === 'image' && file.previewUrl ? (
                      <div className="aspect-video w-full rounded-lg overflow-hidden border bg-muted">
                        <img 
                          src={file.previewUrl} 
                          alt={file.name} 
                          className="h-full w-full object-cover"
                        />
                      </div>
                    ) : (
                      <div className="aspect-video w-full rounded-lg flex flex-col items-center justify-center bg-muted border border-dashed">
                        <FileTypeIcon type={file.type} />
                        <span className="text-xs text-muted-foreground mt-2 uppercase font-semibold">
                          {file.extension} File
                        </span>
                      </div>
                    )}

                    <div className="grid gap-3 p-4 bg-muted/50 rounded-xl border border-border/50">
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <HardDrive className="h-4 w-4" />
                          <span>Size</span>
                        </div>
                        <span className="font-semibold">{formatBytes(file.size)}</span>
                      </div>
                      <Separator className="bg-border/30" />
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Calendar className="h-4 w-4" />
                          <span>Modified</span>
                        </div>
                        <span className="font-semibold">{format(file.lastModified, 'PPP')}</span>
                      </div>
                      <Separator className="bg-border/30" />
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Clock className="h-4 w-4" />
                          <span>Last Accessed</span>
                        </div>
                        <span className="font-semibold">{format(file.lastAccessed || file.lastModified, 'PPP')}</span>
                      </div>
                    </div>

                    <div className="space-y-1.5 px-1">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] uppercase font-bold text-muted-foreground tracking-wider">Path</span>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-6 px-2 text-xs gap-1"
                          onClick={(e) => copyPath(file.path, file.id, e)}
                          data-testid={`button-copy-path-list-dialog-${file.id}`}
                        >
                          {copiedId === file.id ? <Check className="h-3 w-3 text-green-500" /> : <Copy className="h-3 w-3" />}
                          {copiedId === file.id ? 'Copied!' : 'Copy'}
                        </Button>
                      </div>
                      <p className="text-xs font-mono bg-muted p-2 rounded border border-border/50 break-all">
                        {file.path}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 mt-4 pt-4 border-t">
                    <Button variant="outline" size="sm" className="flex-1 gap-2 rounded-full" onClick={() => window.open(file.path)}>
                      <ExternalLink className="h-3.5 w-3.5" />
                      Open
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1 gap-2 rounded-full">
                      <Download className="h-3.5 w-3.5" />
                      Download
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 pb-20">
      <AnimatePresence mode="popLayout">
        {files.map((file) => (
          <motion.div
            layout
            key={file.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.2 }}
          >
            <Dialog>
              <Card 
                className={`relative group cursor-pointer transition-all duration-200 hover:shadow-md border-2 ${
                  selectedIds.includes(file.id) ? "border-primary bg-primary/5" : "border-transparent hover:border-border"
                }`}
                onClick={() => onToggleSelect(file.id)}
              >
                <div className="absolute top-3 right-3 z-10 flex items-center gap-1.5">
                  <Button 
                    variant="secondary" 
                    size="icon" 
                    className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={(e) => copyPath(file.path, file.id, e)}
                    title="Copy path"
                    data-testid={`button-copy-path-${file.id}`}
                  >
                    {copiedId === file.id ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                  </Button>
                  <DialogTrigger asChild onClick={(e) => e.stopPropagation()}>
                    <Button variant="secondary" size="icon" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity" title="View details">
                      <Eye className="h-4 w-4" />
                    </Button>
                  </DialogTrigger>
                  <Checkbox 
                    checked={selectedIds.includes(file.id)} 
                    onCheckedChange={() => onToggleSelect(file.id)}
                    className={`transition-opacity ${selectedIds.includes(file.id) ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}
                  />
                </div>
                
                <div className="p-4 flex flex-col gap-3">
                  <div className="flex items-start justify-between">
                    <div className="p-2 bg-background rounded-lg shadow-sm">
                      <FileTypeIcon type={file.type} />
                    </div>
                    <Badge variant="secondary" className="font-mono text-[10px]">
                      {file.extension.toUpperCase()}
                    </Badge>
                  </div>
                  
                  <div>
                    <h4 className="font-medium truncate" title={file.name}>{file.name}</h4>
                    <p className="text-xs text-muted-foreground truncate" title={file.path}>{file.path}</p>
                  </div>

                  <div className="flex items-center justify-between text-xs text-muted-foreground mt-2 pt-3 border-t">
                    <span>{formatBytes(file.size)}</span>
                    <span>{format(file.lastModified, 'MMM d, yyyy')}</span>
                  </div>
                </div>
              </Card>

              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <FileTypeIcon type={file.type} />
                    <span className="truncate">{file.name}</span>
                  </DialogTitle>
                  <DialogDescription>
                    File details and metadata
                  </DialogDescription>
                </DialogHeader>
                
                <div className="mt-4 space-y-4">
                  {file.type === 'image' && file.previewUrl ? (
                    <div className="aspect-video w-full rounded-lg overflow-hidden border bg-muted">
                      <img 
                        src={file.previewUrl} 
                        alt={file.name} 
                        className="h-full w-full object-cover"
                      />
                    </div>
                  ) : (
                    <div className="aspect-video w-full rounded-lg flex flex-col items-center justify-center bg-muted border border-dashed">
                      <FileTypeIcon type={file.type} />
                      <span className="text-xs text-muted-foreground mt-2 uppercase font-semibold">
                        {file.extension} File
                      </span>
                    </div>
                  )}

                  <div className="grid gap-3 p-4 bg-muted/50 rounded-xl border border-border/50">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <HardDrive className="h-4 w-4" />
                        <span>Size</span>
                      </div>
                      <span className="font-semibold">{formatBytes(file.size)}</span>
                    </div>
                    <Separator className="bg-border/30" />
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Calendar className="h-4 w-4" />
                        <span>Modified</span>
                      </div>
                      <span className="font-semibold">{format(file.lastModified, 'PPP')}</span>
                    </div>
                    <Separator className="bg-border/30" />
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Clock className="h-4 w-4" />
                        <span>Last Accessed</span>
                      </div>
                      <span className="font-semibold">{format(file.lastAccessed || file.lastModified, 'PPP')}</span>
                    </div>
                  </div>

                  <div className="space-y-1.5 px-1">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] uppercase font-bold text-muted-foreground tracking-wider">Path</span>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-6 px-2 text-xs gap-1"
                        onClick={(e) => copyPath(file.path, file.id, e)}
                        data-testid={`button-copy-path-dialog-${file.id}`}
                      >
                        {copiedId === file.id ? <Check className="h-3 w-3 text-green-500" /> : <Copy className="h-3 w-3" />}
                        {copiedId === file.id ? 'Copied!' : 'Copy'}
                      </Button>
                    </div>
                    <p className="text-xs font-mono bg-muted p-2 rounded border border-border/50 break-all">
                      {file.path}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 mt-4 pt-4 border-t">
                  <Button variant="outline" size="sm" className="flex-1 gap-2 rounded-full" onClick={() => window.open(file.path)}>
                    <ExternalLink className="h-3.5 w-3.5" />
                    Open Location
                  </Button>
                  <Button variant="secondary" size="sm" className="flex-1 gap-2 rounded-full">
                    <Download className="h-3.5 w-3.5" />
                    Properties
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
