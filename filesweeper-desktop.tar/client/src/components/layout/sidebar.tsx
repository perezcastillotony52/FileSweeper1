import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { FileType } from "@/lib/mock-data";
import { RotateCcw, Filter, Calendar, FolderOpen, ChevronRight, ChevronDown, HardDrive, Search, Cloud, Folder } from "lucide-react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useState, type ReactNode } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";

// Simulated folder structure for browsing
const FOLDER_TREE: Record<string, string[]> = {
  "C:/": ["Users", "Program Files", "Program Files (x86)", "Windows", "Temp"],
  "C:/Users": ["Admin", "Public", "Default"],
  "C:/Users/Admin": ["Desktop", "Documents", "Downloads", "Pictures", "Videos", "Music", "AppData"],
  "C:/Users/Admin/Desktop": ["Projects", "Shortcuts"],
  "C:/Users/Admin/Documents": ["Work", "Personal", "Reports"],
  "C:/Users/Admin/Downloads": [],
  "C:/Users/Admin/Pictures": ["Screenshots", "Camera Roll", "Saved Pictures"],
  "C:/Users/Admin/Videos": ["Captures", "Movies"],
  "C:/Users/Admin/Music": ["Playlists", "Albums"],
  "C:/Users/Admin/AppData": ["Local", "Roaming"],
  "C:/Program Files": ["Microsoft", "Adobe", "Common Files"],
  "D:/": ["Games", "Backup", "Work", "Media"],
  "D:/Games": ["Steam", "Epic Games", "GOG"],
  "D:/Backup": ["Photos", "Documents", "System"],
  "D:/Work": ["Project-X", "Project-Y", "Archives"],
  "D:/Work/Project-X": ["Assets", "Source", "Build"],
  "D:/Media": ["Movies", "Music", "Photos"],
  "E:/": ["External Backup", "Archive"],
};

export type SourceType = 'local' | 'google-drive' | 'dropbox' | 'onedrive';

export interface RecentScan {
  id: string;
  scanPath: string;
  totalFiles: number;
  totalSizeMB: number;
  createdAt: string;
}

interface FiltersProps {
  ageType: 'days' | 'months' | 'years';
  setAgeType: (type: 'days' | 'months' | 'years') => void;
  ageValue: number;
  setAgeValue: (value: number) => void;
  minSizeMB: number;
  setMinSizeMB: (size: number) => void;
  selectedTypes: FileType[];
  setSelectedTypes: (types: FileType[]) => void;
  selectedPath: string;
  setSelectedPath: (path: string) => void;
  onReset: () => void;
  onScan?: () => void;
  sourceType?: SourceType;
  setSourceType?: (type: SourceType) => void;
  googleDriveConnected?: boolean;
  dropboxConnected?: boolean;
  oneDriveConnected?: boolean;
  recentScans?: RecentScan[];
  onLoadScan?: (scan: RecentScan) => void;
  currentScanId?: string;
}

const FILE_TYPES: { value: FileType; label: string }[] = [
  { value: "image", label: "Images" },
  { value: "video", label: "Videos" },
  { value: "document", label: "Documents" },
  { value: "archive", label: "Archives" },
  { value: "audio", label: "Audio" },
  { value: "other", label: "Others" },
];

const DRIVES = [
  { label: "Local Disk (C:)", path: "C:/" },
  { label: "Local Disk (D:)", path: "D:/" },
  { label: "External (E:)", path: "E:/" },
];

const RECENT_PATHS = [
  "C:/Users/Admin/Downloads",
  "C:/Users/Admin/Documents",
  "D:/Work/Project-X/Assets",
];

export function Filters({ 
  ageType,
  setAgeType,
  ageValue,
  setAgeValue,
  minSizeMB, 
  setMinSizeMB,
  selectedTypes,
  setSelectedTypes,
  selectedPath,
  setSelectedPath,
  onReset,
  onScan,
  sourceType = 'local',
  setSourceType,
  googleDriveConnected = false,
  dropboxConnected = false,
  oneDriveConnected = false,
  recentScans = [],
  onLoadScan,
  currentScanId
}: FiltersProps) {
  const [customPath, setCustomPath] = useState("");
  const [isBrowseOpen, setIsBrowseOpen] = useState(false);
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set(["C:/", "C:/Users", "C:/Users/Admin"]));
  const [browseSelectedPath, setBrowseSelectedPath] = useState(selectedPath);
  
  const toggleType = (type: FileType) => {
    if (selectedTypes.includes(type)) {
      setSelectedTypes(selectedTypes.filter(t => t !== type));
    } else {
      setSelectedTypes([...selectedTypes, type]);
    }
  };

  const getLimit = () => {
    if (ageType === 'days') return 365;
    if (ageType === 'months') return 24;
    return 10;
  };

  const toggleFolder = (path: string) => {
    const newExpanded = new Set(expandedFolders);
    if (newExpanded.has(path)) {
      newExpanded.delete(path);
    } else {
      newExpanded.add(path);
    }
    setExpandedFolders(newExpanded);
  };

  const renderFolderTree = (parentPath: string, level: number = 0): ReactNode[] => {
    const folders = FOLDER_TREE[parentPath] || [];
    return folders.map(folder => {
      const fullPath = parentPath.endsWith('/') ? `${parentPath}${folder}` : `${parentPath}/${folder}`;
      const hasChildren = FOLDER_TREE[fullPath] && FOLDER_TREE[fullPath].length > 0;
      const isExpanded = expandedFolders.has(fullPath);
      const isSelected = browseSelectedPath === fullPath;

      return (
        <div key={fullPath}>
          <div
            className={`flex items-center gap-1 py-1.5 px-2 rounded-md cursor-pointer hover:bg-muted/50 ${isSelected ? 'bg-primary/10 text-primary' : ''}`}
            style={{ paddingLeft: `${level * 16 + 8}px` }}
            onClick={() => setBrowseSelectedPath(fullPath)}
            data-testid={`folder-${folder}`}
          >
            {hasChildren ? (
              <button
                onClick={(e) => { e.stopPropagation(); toggleFolder(fullPath); }}
                className="p-0.5 hover:bg-muted rounded"
              >
                {isExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
              </button>
            ) : (
              <span className="w-4" />
            )}
            <Folder className={`w-4 h-4 ${isSelected ? 'text-primary' : 'text-yellow-500'}`} />
            <span className="text-xs truncate">{folder}</span>
          </div>
          {hasChildren && isExpanded && renderFolderTree(fullPath, level + 1)}
        </div>
      );
    });
  };

  return (
    <Card className="h-full border-0 shadow-none bg-transparent">
      <CardHeader className="px-0 pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Scan Settings
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={onReset} className="h-8 px-2 text-muted-foreground hover:bg-muted">
            <RotateCcw className="w-3 h-3 mr-1" />
            Reset
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="px-0 space-y-6">
        {/* Source Type Selection */}
        <div className="space-y-4">
          <Label className="text-sm font-semibold flex items-center gap-2 text-primary">
            <HardDrive className="w-4 h-4" />
            Select Source
          </Label>
          
          <div className="grid grid-cols-2 gap-2">
            <Button
              variant={sourceType === 'local' ? "secondary" : "outline"}
              size="sm"
              className="flex-col h-14 text-[10px] gap-1 px-1 border-border/60"
              onClick={() => setSourceType?.('local')}
              data-testid="button-source-local"
            >
              <HardDrive className="w-4 h-4 opacity-70" />
              Local Disk
            </Button>
            <Button
              variant={sourceType === 'google-drive' ? "secondary" : "outline"}
              size="sm"
              className={`flex-col h-14 text-[10px] gap-1 px-1 border-border/60 ${!googleDriveConnected ? 'opacity-50' : ''}`}
              onClick={() => googleDriveConnected && setSourceType?.('google-drive')}
              disabled={!googleDriveConnected}
              data-testid="button-source-gdrive"
            >
              <Cloud className="w-4 h-4 opacity-70" />
              Google Drive
              {!googleDriveConnected && <span className="text-[8px] text-muted-foreground">Not connected</span>}
            </Button>
            <Button
              variant={sourceType === 'dropbox' ? "secondary" : "outline"}
              size="sm"
              className={`flex-col h-14 text-[10px] gap-1 px-1 border-border/60 ${!dropboxConnected ? 'opacity-50' : ''}`}
              onClick={() => dropboxConnected && setSourceType?.('dropbox')}
              disabled={!dropboxConnected}
              data-testid="button-source-dropbox"
            >
              <Cloud className="w-4 h-4 opacity-70" />
              Dropbox
              {!dropboxConnected && <span className="text-[8px] text-muted-foreground">Not connected</span>}
            </Button>
            <Button
              variant={sourceType === 'onedrive' ? "secondary" : "outline"}
              size="sm"
              className={`flex-col h-14 text-[10px] gap-1 px-1 border-border/60 ${!oneDriveConnected ? 'opacity-50' : ''}`}
              onClick={() => oneDriveConnected && setSourceType?.('onedrive')}
              disabled={!oneDriveConnected}
              data-testid="button-source-onedrive"
            >
              <Cloud className="w-4 h-4 opacity-70" />
              OneDrive
              {!oneDriveConnected && <span className="text-[8px] text-muted-foreground">Not connected</span>}
            </Button>
          </div>
        </div>

        {/* Drive & Path Selection - Only show for local */}
        {sourceType === 'local' && (
          <div className="space-y-4">
          <Label className="text-[11px] text-muted-foreground uppercase tracking-wider font-bold">Local Drives</Label>
          
          <div className="grid grid-cols-3 gap-2">
            {DRIVES.map((drive) => (
              <Button
                key={drive.path}
                variant={selectedPath.startsWith(drive.path) ? "secondary" : "outline"}
                size="sm"
                className="flex-col h-14 text-[10px] gap-1 px-1 border-border/60"
                onClick={() => setSelectedPath(drive.path)}
              >
                <HardDrive className="w-4 h-4 opacity-70" />
                {drive.path}
              </Button>
            ))}
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-[11px] text-muted-foreground uppercase tracking-wider font-bold">Select Folder</Label>
              <Button
                variant="outline"
                size="sm"
                className="h-7 text-xs gap-1.5 px-2"
                onClick={() => {
                  setBrowseSelectedPath(selectedPath);
                  setIsBrowseOpen(true);
                }}
                data-testid="button-browse-folders"
              >
                <FolderOpen className="w-3.5 h-3.5" />
                Browse
              </Button>
            </div>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <FolderOpen className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                <Input 
                  placeholder="Paste path here..." 
                  className="pl-8 h-8 text-xs bg-muted/30 border-border/50"
                  value={customPath}
                  onChange={(e) => setCustomPath(e.target.value)}
                  data-testid="input-custom-path"
                />
              </div>
              <Button 
                size="sm" 
                className="h-8 px-3" 
                onClick={() => customPath && setSelectedPath(customPath)}
                disabled={!customPath}
                data-testid="button-set-path"
              >
                Set
              </Button>
              <Button 
                size="sm" 
                className="h-8 px-3 gap-1" 
                variant="default"
                onClick={() => {
                  if (customPath) {
                    setSelectedPath(customPath);
                    setTimeout(() => onScan?.(), 100);
                  }
                }}
                disabled={!customPath}
                data-testid="button-scan-custom-path"
              >
                <Search className="w-3 h-3" />
                Scan
              </Button>
            </div>
          </div>

          <div className="space-y-1.5">
            <Label className="text-[11px] text-muted-foreground uppercase tracking-wider font-bold">Quick Select</Label>
            <div className="flex flex-col gap-1">
              {RECENT_PATHS.map((path) => (
                <Button
                  key={path}
                  variant={selectedPath === path ? "secondary" : "ghost"}
                  size="sm"
                  className="w-full justify-start h-8 text-[11px] font-normal px-2 rounded-md truncate group"
                  onClick={() => setSelectedPath(path)}
                >
                  <FolderOpen className={`w-3 h-3 mr-2 shrink-0 ${selectedPath === path ? 'text-primary' : 'text-muted-foreground'}`} />
                  <span className="truncate">{path}</span>
                </Button>
              ))}
            </div>
          </div>
        </div>
        )}

        {/* Google Drive Section */}
        {sourceType === 'google-drive' && googleDriveConnected && (
          <div className="space-y-4">
            <Label className="text-[11px] text-muted-foreground uppercase tracking-wider font-bold">Google Drive</Label>
            <div className="p-3 bg-blue-500/10 rounded-lg border border-blue-500/20">
              <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400">
                <Cloud className="w-4 h-4" />
                <span className="text-xs font-medium">Connected to Google Drive</span>
              </div>
              <p className="text-[10px] text-muted-foreground mt-1">Files will be scanned from your Google Drive account</p>
              <Button 
                size="sm" 
                className="mt-3 w-full h-8 gap-1" 
                variant="default"
                onClick={() => {
                  setSelectedPath('gdrive://root');
                  setTimeout(() => onScan?.(), 100);
                }}
                data-testid="button-scan-gdrive"
              >
                <Search className="w-3 h-3" />
                Scan Google Drive
              </Button>
            </div>
          </div>
        )}

        {/* Dropbox Section */}
        {sourceType === 'dropbox' && dropboxConnected && (
          <div className="space-y-4">
            <Label className="text-[11px] text-muted-foreground uppercase tracking-wider font-bold">Dropbox</Label>
            <div className="p-3 bg-blue-500/10 rounded-lg border border-blue-500/20">
              <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400">
                <Cloud className="w-4 h-4" />
                <span className="text-xs font-medium">Connected to Dropbox</span>
              </div>
              <p className="text-[10px] text-muted-foreground mt-1">Files will be scanned from your Dropbox account</p>
              <Button 
                size="sm" 
                className="mt-3 w-full h-8 gap-1" 
                variant="default"
                onClick={() => {
                  setSelectedPath('dropbox://');
                  setTimeout(() => onScan?.(), 100);
                }}
                data-testid="button-scan-dropbox"
              >
                <Search className="w-3 h-3" />
                Scan Dropbox
              </Button>
            </div>
          </div>
        )}

        {/* OneDrive Section */}
        {sourceType === 'onedrive' && oneDriveConnected && (
          <div className="space-y-4">
            <Label className="text-[11px] text-muted-foreground uppercase tracking-wider font-bold">OneDrive</Label>
            <div className="p-3 bg-blue-500/10 rounded-lg border border-blue-500/20">
              <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400">
                <Cloud className="w-4 h-4" />
                <span className="text-xs font-medium">Connected to OneDrive</span>
              </div>
              <p className="text-[10px] text-muted-foreground mt-1">Files will be scanned from your OneDrive account</p>
              <Button 
                size="sm" 
                className="mt-3 w-full h-8 gap-1" 
                variant="default"
                onClick={() => {
                  setSelectedPath('onedrive://');
                  setTimeout(() => onScan?.(), 100);
                }}
                data-testid="button-scan-onedrive"
              >
                <Search className="w-3 h-3" />
                Scan OneDrive
              </Button>
            </div>
          </div>
        )}

        <Separator className="bg-border/40" />

        {/* Age Filter */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label className="text-sm font-medium flex items-center gap-2">
              <Calendar className="w-3.5 h-3.5" />
              Last
            </Label>
            <Badge variant="outline" className="font-mono text-[10px] bg-muted/50 border-0">
              {ageValue} {ageValue === 1 ? ageType.slice(0, -1) : ageType}
            </Badge>
          </div>
          
          <Tabs value={ageType} onValueChange={(v: any) => {
            setAgeType(v);
            setAgeValue(1);
          }} className="w-full">
            <TabsList className="grid w-full grid-cols-3 h-8 p-1">
              <TabsTrigger value="days" className="text-[10px]">Days</TabsTrigger>
              <TabsTrigger value="months" className="text-[10px]">Months</TabsTrigger>
              <TabsTrigger value="years" className="text-[10px]">Years</TabsTrigger>
            </TabsList>
          </Tabs>

          <Slider
            value={[ageValue]}
            onValueChange={(val) => setAgeValue(val[0])}
            max={getLimit()}
            min={1}
            step={1}
            className="w-full"
          />
        </div>

        <Separator className="bg-border/40" />

        {/* Size Filter */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label className="text-sm font-medium">Minimum Size</Label>
            <Badge variant="outline" className="font-mono text-[10px] bg-muted/50 border-0">{minSizeMB} MB</Badge>
          </div>
          <Slider
            value={[minSizeMB]}
            onValueChange={(val) => setMinSizeMB(val[0])}
            max={1000}
            min={0}
            step={10}
            className="w-full"
          />
        </div>

        <Separator className="bg-border/40" />

        {/* Type Filter */}
        <div className="space-y-3">
          <Label className="text-sm font-medium mb-2 block">File Types</Label>
          <div className="grid grid-cols-1 gap-1.5">
            {FILE_TYPES.map((type) => (
              <div key={type.value} className="flex items-center justify-between rounded-lg border border-border/40 p-2 hover:bg-muted/30 transition-colors">
                <Label htmlFor={`type-${type.value}`} className="flex-1 cursor-pointer text-xs">
                  {type.label}
                </Label>
                <Switch
                  id={`type-${type.value}`}
                  checked={selectedTypes.includes(type.value)}
                  onCheckedChange={() => toggleType(type.value)}
                  className="scale-75 origin-right"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Recent Scans Section */}
        {recentScans.length > 0 && (
          <>
            <Separator className="bg-border/40" />
            <div className="space-y-3">
              <Label className="text-sm font-semibold flex items-center gap-2 text-primary">
                <Calendar className="w-4 h-4" />
                Recently Scanned
              </Label>
              <div className="space-y-1.5 max-h-40 overflow-y-auto">
                {recentScans.slice(0, 5).map((scan) => {
                  const isActive = currentScanId === scan.id;
                  const scanDate = new Date(scan.createdAt);
                  const formattedDate = scanDate.toLocaleDateString('en-US', { 
                    month: 'short', 
                    day: 'numeric',
                    hour: 'numeric',
                    minute: '2-digit'
                  });
                  return (
                    <button
                      key={scan.id}
                      onClick={() => onLoadScan?.(scan)}
                      className={`w-full text-left p-2.5 rounded-lg transition-all duration-200 group ${
                        isActive 
                          ? 'bg-primary/10 border border-primary/30' 
                          : 'bg-muted/30 hover:bg-muted/60 border border-transparent'
                      }`}
                      data-testid={`recent-scan-${scan.id}`}
                    >
                      <div className="flex items-center justify-between">
                        <span className={`text-xs font-medium truncate ${isActive ? 'text-primary' : ''}`}>
                          {scan.scanPath}
                        </span>
                        {isActive && (
                          <Badge variant="secondary" className="text-[9px] px-1.5 py-0 h-4">
                            Active
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-2 mt-1 text-[10px] text-muted-foreground">
                        <span>{scan.totalFiles} files</span>
                        <span>•</span>
                        <span>{formattedDate}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </>
        )}
      </CardContent>

      {/* Folder Browser Dialog */}
      <Dialog open={isBrowseOpen} onOpenChange={setIsBrowseOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FolderOpen className="w-5 h-5" />
              Browse Folders
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-3">
            <div className="text-xs text-muted-foreground bg-muted/50 p-2 rounded-md font-mono truncate">
              {browseSelectedPath || "Select a folder..."}
            </div>
            
            <ScrollArea className="h-[300px] border rounded-lg p-2">
              {/* Drive roots */}
              {DRIVES.map(drive => {
                const isExpanded = expandedFolders.has(drive.path);
                const isSelected = browseSelectedPath === drive.path;
                return (
                  <div key={drive.path}>
                    <div
                      className={`flex items-center gap-1 py-1.5 px-2 rounded-md cursor-pointer hover:bg-muted/50 ${isSelected ? 'bg-primary/10 text-primary' : ''}`}
                      onClick={() => setBrowseSelectedPath(drive.path)}
                      data-testid={`drive-${drive.path}`}
                    >
                      <button
                        onClick={(e) => { e.stopPropagation(); toggleFolder(drive.path); }}
                        className="p-0.5 hover:bg-muted rounded"
                      >
                        {isExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                      </button>
                      <HardDrive className={`w-4 h-4 ${isSelected ? 'text-primary' : 'text-muted-foreground'}`} />
                      <span className="text-xs font-medium">{drive.label}</span>
                    </div>
                    {isExpanded && renderFolderTree(drive.path, 1)}
                  </div>
                );
              })}
            </ScrollArea>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setIsBrowseOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={() => {
                setSelectedPath(browseSelectedPath);
                setCustomPath(browseSelectedPath);
                setIsBrowseOpen(false);
              }}
              disabled={!browseSelectedPath}
            >
              Select Folder
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
