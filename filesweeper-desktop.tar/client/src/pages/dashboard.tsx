import { useState, useMemo, useCallback, useEffect } from "react";
import { generateMockFiles, FileItem, FileType as MockFileType, formatBytes } from "@/lib/mock-data";
import { FileGrid } from "@/components/file-manager/file-grid";
import { StatsCards } from "@/components/file-manager/stats-cards";
import { Filters } from "@/components/layout/sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { 
  Search, 
  Trash2, 
  Archive, 
  Download, 
  RefreshCw, 
  LayoutGrid, 
  List,
  Menu,
  Monitor,
  Smartphone,
  X,
  AlertTriangle,
  FolderArchive,
  CheckCircle2,
  FileText,
  Printer,
  FileDown,
  Minus,
  Square,
  LogIn,
  LogOut,
  Shield,
  User,
  FileSpreadsheet,
  FileType,
  Share2,
  Keyboard,
  FolderOpen
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { 
  Sheet, 
  SheetContent, 
  SheetTrigger 
} from "@/components/ui/sheet";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  createScanSession, 
  addFilesToScan, 
  getFilesBySession, 
  performFileAction,
  toFileItem,
  getGoogleDriveStatus,
  scanGoogleDrive,
  getDropboxStatus,
  scanDropbox,
  getOneDriveStatus,
  scanOneDrive,
  getAllScanSessions,
  type ScanSession
} from "@/lib/api";
import type { SourceType } from "@/components/layout/sidebar";

export default function Dashboard() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user, isLoading: isAuthLoading, isAuthenticated: isLoggedIn } = useAuth();
  
  // Current scan session
  const [currentSession, setCurrentSession] = useState<ScanSession | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [viewMode, setViewMode] = useState<'windows' | 'mobile'>('windows');
  const [displayView, setDisplayView] = useState<'grid' | 'list'>('grid');
  
  // Directory Selection
  const [selectedPath, setSelectedPath] = useState("C:/Users/Admin/Downloads");
  
  // Source Type (local or cloud)
  const [sourceType, setSourceType] = useState<SourceType>('local');
  
  // Check cloud connection status
  const { data: googleDriveStatus } = useQuery({
    queryKey: ['/api/cloud/google-drive/status'],
    queryFn: getGoogleDriveStatus,
    staleTime: 60000,
  });
  
  const { data: dropboxStatus } = useQuery({
    queryKey: ['/api/cloud/dropbox/status'],
    queryFn: getDropboxStatus,
    staleTime: 60000,
  });
  
  const { data: oneDriveStatus } = useQuery({
    queryKey: ['/api/cloud/onedrive/status'],
    queryFn: getOneDriveStatus,
    staleTime: 60000,
  });

  // Fetch recent scan sessions
  const { data: recentScans = [] } = useQuery({
    queryKey: ['/api/scans'],
    queryFn: getAllScanSessions,
    staleTime: 30000,
  });

  // Load a previous scan session
  const loadPreviousScan = (scan: { id: string; scanPath: string; createdAt: string }) => {
    // Find full session from recentScans
    const fullSession = recentScans.find(s => s.id === scan.id);
    if (fullSession) {
      setCurrentSession(fullSession);
      setSelectedIds([]);
      toast({
        title: "Scan Loaded",
        description: `Loaded scan from ${format(new Date(scan.createdAt), 'MMM d, yyyy h:mm a')}`,
      });
    }
  };
  
  // Dialog States
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isArchiveDialogOpen, setIsArchiveDialogOpen] = useState(false);
  const [isBackupDialogOpen, setIsBackupDialogOpen] = useState(false);
  const [isReportDialogOpen, setIsReportDialogOpen] = useState(false);
  const [isShortcutsDialogOpen, setIsShortcutsDialogOpen] = useState(false);
  const [pendingAction, setPendingAction] = useState<string | null>(null);
  
  // Feedback States
  const [showSuccessOverlay, setShowSuccessOverlay] = useState(false);
  const [lastAction, setLastAction] = useState<{ name: string; count: number; files: FileItem[]; destination?: string } | null>(null);
  
  // Destination paths for file actions
  const [backupDestination, setBackupDestination] = useState("D:/Backup/FileSweeper");
  const [archiveDestination, setArchiveDestination] = useState("D:/Archive/Compressed");
  const [deleteDestination, setDeleteDestination] = useState("C:/Users/Admin/$Recycle.Bin");
  
  // Custom path mode
  const [useCustomBackupPath, setUseCustomBackupPath] = useState(false);
  const [useCustomArchivePath, setUseCustomArchivePath] = useState(false);
  const [useCustomDeletePath, setUseCustomDeletePath] = useState(false);
  
  // Preset paths
  const backupPresets = [
    "D:/Backup/FileSweeper",
    "E:/Backups",
    "C:/Users/Admin/Backups",
    "F:/External Backup"
  ];
  const archivePresets = [
    "D:/Archive/Compressed",
    "E:/Archives",
    "C:/Users/Admin/Archives",
    "F:/External Archive"
  ];
  const deletePresets = [
    "C:/Users/Admin/$Recycle.Bin",
    "D:/$Recycle.Bin",
    "Permanent Delete (No Recovery)"
  ];

  // Filters
  const [searchQuery, setSearchQuery] = useState("");
  const [ageType, setAgeType] = useState<'days' | 'months' | 'years'>('days');
  const [ageValue, setAgeValue] = useState(30);
  const [minSizeMB, setMinSizeMB] = useState(0);
  const [selectedTypes, setSelectedTypes] = useState<MockFileType[]>(["image", "video", "document", "archive", "audio", "other"]);
  
  // Selection
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Fetch files for current session
  const { data: sessionFiles = [], isLoading: isLoadingFiles, refetch: refetchFiles } = useQuery({
    queryKey: ['/api/scans', currentSession?.id, 'files'],
    queryFn: async () => {
      if (!currentSession?.id) return [];
      const files = await getFilesBySession(currentSession.id);
      return files.map(toFileItem);
    },
    enabled: !!currentSession?.id,
  });

  // Create scan mutation
  const createScanMutation = useMutation({
    mutationFn: async () => {
      // Determine scan source
      const isGoogleDrive = sourceType === 'google-drive' || selectedPath.startsWith('gdrive://');
      const isDropbox = sourceType === 'dropbox' || selectedPath.startsWith('dropbox://');
      const isOneDrive = sourceType === 'onedrive' || selectedPath.startsWith('onedrive://');
      const isCloud = isGoogleDrive || isDropbox || isOneDrive;
      
      const scanPath = isGoogleDrive ? 'Google Drive' 
        : isDropbox ? 'Dropbox' 
        : isOneDrive ? 'OneDrive' 
        : selectedPath;
      
      // Create a new scan session
      const session = await createScanSession({
        scanPath,
        minAgeDays: ageType === 'days' ? ageValue : ageType === 'months' ? ageValue * 30 : ageValue * 365,
        minSizeMB,
        fileTypes: JSON.stringify(selectedTypes),
      });
      
      let filesToInsert;
      
      if (isGoogleDrive) {
        // Scan Google Drive
        const cloudFiles = await scanGoogleDrive();
        filesToInsert = cloudFiles.map(file => ({
          sessionId: session.id,
          name: file.name,
          path: file.path,
          size: file.size,
          type: file.type,
          extension: file.extension,
          lastModified: new Date(file.lastModified),
          lastAccessed: new Date(file.lastAccessed),
          previewUrl: file.previewUrl,
          isSelected: false,
          actionTaken: null,
        }));
      } else if (isDropbox) {
        // Scan Dropbox
        const cloudFiles = await scanDropbox();
        filesToInsert = cloudFiles.map(file => ({
          sessionId: session.id,
          name: file.name,
          path: file.path,
          size: file.size,
          type: file.type,
          extension: file.extension,
          lastModified: new Date(file.lastModified),
          lastAccessed: new Date(file.lastAccessed),
          previewUrl: file.previewUrl,
          isSelected: false,
          actionTaken: null,
        }));
      } else if (isOneDrive) {
        // Scan OneDrive
        const cloudFiles = await scanOneDrive();
        filesToInsert = cloudFiles.map(file => ({
          sessionId: session.id,
          name: file.name,
          path: file.path,
          size: file.size,
          type: file.type,
          extension: file.extension,
          lastModified: new Date(file.lastModified),
          lastAccessed: new Date(file.lastAccessed),
          previewUrl: file.previewUrl,
          isSelected: false,
          actionTaken: null,
        }));
      } else {
        // Generate mock files for local scan (simulated)
        const mockFiles = generateMockFiles(100);
        filesToInsert = mockFiles.map(file => ({
          sessionId: session.id,
          name: file.name,
          path: `${selectedPath}/${file.name}`,
          size: file.size,
          type: file.type,
          extension: file.extension,
          lastModified: file.lastModified,
          lastAccessed: file.lastAccessed,
          previewUrl: file.previewUrl || null,
          isSelected: false,
          actionTaken: null,
        }));
      }
      
      await addFilesToScan(session.id, filesToInsert);
      
      return { session, isCloud, scanPath };
    },
    onSuccess: ({ session, isCloud, scanPath }) => {
      setCurrentSession(session);
      setSelectedIds([]);
      queryClient.invalidateQueries({ queryKey: ['/api/scans'] });
      toast({
        title: "Scan Complete",
        description: isCloud 
          ? `Found files in your ${scanPath}` 
          : `Found files in ${scanPath}`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Scan Failed",
        description: error?.message || "Could not complete the scan. Please try again.",
        variant: "destructive",
      });
    },
  });

  // File action mutation
  const fileActionMutation = useMutation({
    mutationFn: async ({ actionType, destination }: { actionType: "backup" | "archive" | "delete"; destination?: string }) => {
      if (!currentSession?.id) throw new Error("No active session");
      return performFileAction(selectedIds, actionType, currentSession.id, destination);
    },
    onSuccess: (result, { actionType }) => {
      const affectedFiles = sessionFiles.filter(f => selectedIds.includes(f.id));
      const actionName = actionType === "delete" ? "Delete Permanently" : actionType.charAt(0).toUpperCase() + actionType.slice(1);
      
      setLastAction({ 
        name: actionName, 
        count: affectedFiles.length, 
        files: affectedFiles 
      });
      
      setSelectedIds([]);
      setIsDeleteDialogOpen(false);
      setIsArchiveDialogOpen(false);
      setPendingAction(null);
      setShowSuccessOverlay(true);
      
      // Refresh files list
      refetchFiles();
      
      toast({
        title: "Action Success",
        description: result.message,
        className: "bg-green-50 dark:bg-green-900 border-green-200 dark:border-green-800"
      });

      setTimeout(() => setShowSuccessOverlay(false), 4000);
    },
    onError: () => {
      toast({
        title: "Action Failed",
        description: "Could not complete the action. Please try again.",
        variant: "destructive",
      });
    },
  });

  const simulateScan = useCallback(() => {
    // Check cloud connectivity before scanning
    if (sourceType === 'google-drive' && !googleDriveStatus?.connected) {
      toast({
        title: "Google Drive Not Connected",
        description: "Please connect your Google Drive account first.",
        variant: "destructive",
      });
      return;
    }
    if (sourceType === 'dropbox' && !dropboxStatus?.connected) {
      toast({
        title: "Dropbox Not Connected", 
        description: "Please connect your Dropbox account first.",
        variant: "destructive",
      });
      return;
    }
    if (sourceType === 'onedrive' && !oneDriveStatus?.connected) {
      toast({
        title: "OneDrive Not Connected",
        description: "Please connect your OneDrive account first.",
        variant: "destructive",
      });
      return;
    }
    
    setIsScanning(true);
    createScanMutation.mutate();
    setTimeout(() => setIsScanning(false), 1500);
  }, [createScanMutation, sourceType, googleDriveStatus, dropboxStatus, oneDriveStatus, toast]);

  // Filter Logic - exclude files that have been actioned
  const filteredFiles = useMemo(() => {
    const now = new Date();
    return sessionFiles.filter(file => {
      // Skip files that have already been actioned
      if (file.actionTaken) return false;
      
      const diffMs = now.getTime() - file.lastModified.getTime();
      let fileAgeDays = diffMs / (1000 * 3600 * 24);
      
      let thresholdDays = ageValue;
      if (ageType === 'months') thresholdDays = ageValue * 30;
      if (ageType === 'years') thresholdDays = ageValue * 365;

      if (fileAgeDays < thresholdDays) return false;
      if (file.size < minSizeMB * 1024 * 1024) return false;
      if (!selectedTypes.includes(file.type)) return false;
      if (searchQuery && !file.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;

      return true;
    });
  }, [sessionFiles, ageType, ageValue, minSizeMB, selectedTypes, searchQuery]);

  const handleToggleSelect = (id: string) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const handleSelectAll = () => {
    if (selectedIds.length === filteredFiles.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredFiles.map(f => f.id));
    }
  };

  const confirmAction = (action: string) => {
    if (selectedIds.length === 0) return;
    setPendingAction(action);
    if (action === "Delete Permanently") {
      setIsDeleteDialogOpen(true);
    } else if (action === "Archive") {
      setIsArchiveDialogOpen(true);
    } else {
      performAction(action);
    }
  };

  const performAction = (action: string, destination?: string) => {
    let actionType: "backup" | "archive" | "delete";
    if (action === "Delete Permanently") {
      actionType = "delete";
    } else if (action === "Archive") {
      actionType = "archive";
    } else {
      actionType = "backup";
    }
    
    // Store destination for the success overlay
    const affectedFiles = sessionFiles.filter(f => selectedIds.includes(f.id));
    const dest = destination || (actionType === "delete" ? deleteDestination : actionType === "archive" ? archiveDestination : backupDestination);
    
    fileActionMutation.mutate({ actionType, destination: dest }, {
      onSuccess: () => {
        setLastAction({ 
          name: action, 
          count: affectedFiles.length, 
          files: affectedFiles,
          destination: dest
        });
      }
    });
  };

  const handleResetFilters = () => {
    setAgeType('days');
    setAgeValue(30);
    setMinSizeMB(0);
    setSelectedTypes(["image", "video", "document", "archive", "audio", "other"]);
    setSearchQuery("");
    setSelectedPath("C:/Users/Admin/Downloads");
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadReport = () => {
    if (!lastAction) return;
    const content = `FileSweeper Action Report\n` +
      `Action: ${lastAction.name}\n` +
      `Date: ${format(new Date(), 'yyyy-MM-dd HH:mm:ss')}\n` +
      `Files Processed: ${lastAction.count}\n\n` +
      `VERBOSE LOG:\n` +
      lastAction.files.map(f => 
        `[${f.type.toUpperCase()}] ${f.name}\nPath: ${f.path}\nSize: ${formatBytes(f.size)}\nModified: ${format(f.lastModified, 'yyyy-MM-dd')}\n---`
      ).join('\n');
    
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `filesweeper-report-${format(new Date(), 'yyyyMMdd-HHmmss')}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: "Report Downloaded", description: "The verbose report has been saved to your device." });
  };

  // Export functions for scan results
  const exportToCSV = () => {
    const headers = ['Name', 'Path', 'Type', 'Extension', 'Size (bytes)', 'Size', 'Modified Date', 'Last Accessed'];
    const rows = filteredFiles.map(f => [
      f.name,
      f.path,
      f.type,
      f.extension,
      f.size.toString(),
      formatBytes(f.size),
      format(f.lastModified, 'yyyy-MM-dd'),
      f.lastAccessed ? format(f.lastAccessed, 'yyyy-MM-dd') : ''
    ]);
    
    const csvContent = [headers, ...rows].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `filesweeper-scan-${format(new Date(), 'yyyyMMdd-HHmmss')}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: "Exported to CSV", description: `${filteredFiles.length} files exported successfully.` });
  };

  const exportToTXT = () => {
    const content = `FileSweeper Scan Results\n` +
      `Export Date: ${format(new Date(), 'yyyy-MM-dd HH:mm:ss')}\n` +
      `Total Files: ${filteredFiles.length}\n` +
      `Scan Path: ${selectedPath}\n` +
      `${'='.repeat(60)}\n\n` +
      filteredFiles.map((f, i) => 
        `${i + 1}. ${f.name}\n` +
        `   Path: ${f.path}\n` +
        `   Type: ${f.type.toUpperCase()} (.${f.extension})\n` +
        `   Size: ${formatBytes(f.size)}\n` +
        `   Modified: ${format(f.lastModified, 'yyyy-MM-dd')}\n`
      ).join('\n');
    
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `filesweeper-scan-${format(new Date(), 'yyyyMMdd-HHmmss')}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: "Exported to TXT", description: `${filteredFiles.length} files exported successfully.` });
  };

  const exportToXLSX = async () => {
    const XLSX = await import('xlsx');
    const data = filteredFiles.map(f => ({
      'Name': f.name,
      'Path': f.path,
      'Type': f.type,
      'Extension': f.extension,
      'Size (bytes)': f.size,
      'Size': formatBytes(f.size),
      'Modified Date': format(f.lastModified, 'yyyy-MM-dd'),
      'Last Accessed': f.lastAccessed ? format(f.lastAccessed, 'yyyy-MM-dd') : ''
    }));
    
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Scan Results');
    XLSX.writeFile(wb, `filesweeper-scan-${format(new Date(), 'yyyyMMdd-HHmmss')}.xlsx`);
    toast({ title: "Exported to Excel", description: `${filteredFiles.length} files exported successfully.` });
  };

  const exportToPDF = async () => {
    const { default: jsPDF } = await import('jspdf');
    await import('jspdf-autotable');
    
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text('FileSweeper Scan Results', 14, 22);
    doc.setFontSize(10);
    doc.text(`Export Date: ${format(new Date(), 'yyyy-MM-dd HH:mm:ss')}`, 14, 30);
    doc.text(`Total Files: ${filteredFiles.length}`, 14, 36);
    doc.text(`Scan Path: ${selectedPath}`, 14, 42);
    
    const tableData = filteredFiles.map(f => [
      f.name.substring(0, 30) + (f.name.length > 30 ? '...' : ''),
      f.type,
      formatBytes(f.size),
      format(f.lastModified, 'MM/dd/yy')
    ]);
    
    (doc as any).autoTable({
      head: [['Name', 'Type', 'Size', 'Modified']],
      body: tableData,
      startY: 50,
      styles: { fontSize: 8, cellPadding: 2 },
      headStyles: { fillColor: [59, 130, 246] },
    });
    
    doc.save(`filesweeper-scan-${format(new Date(), 'yyyyMMdd-HHmmss')}.pdf`);
    toast({ title: "Exported to PDF", description: `${filteredFiles.length} files exported successfully.` });
  };

  const isLoading = isScanning || createScanMutation.isPending || isLoadingFiles;

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if typing in an input field
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      // Ctrl/Cmd + A: Select all files
      if ((e.ctrlKey || e.metaKey) && e.key === 'a') {
        e.preventDefault();
        if (filteredFiles.length > 0) {
          setSelectedIds(filteredFiles.map(f => f.id));
          toast({ title: "All files selected", description: `${filteredFiles.length} files selected` });
        }
      }

      // Ctrl/Cmd + D: Deselect all
      if ((e.ctrlKey || e.metaKey) && e.key === 'd') {
        e.preventDefault();
        setSelectedIds([]);
        toast({ title: "Selection cleared" });
      }

      // Ctrl/Cmd + R: Refresh/Scan
      if ((e.ctrlKey || e.metaKey) && e.key === 'r') {
        e.preventDefault();
        if (!isLoading) {
          simulateScan();
        }
      }

      // Delete key: Delete selected files
      if (e.key === 'Delete' && selectedIds.length > 0) {
        e.preventDefault();
        setIsDeleteDialogOpen(true);
      }

      // Escape: Clear selection
      if (e.key === 'Escape') {
        e.preventDefault();
        setSelectedIds([]);
      }

      // Ctrl/Cmd + E: Export menu (show CSV export)
      if ((e.ctrlKey || e.metaKey) && e.key === 'e') {
        e.preventDefault();
        if (filteredFiles.length > 0) {
          exportToCSV();
        }
      }

      // Ctrl/Cmd + B: Backup selected
      if ((e.ctrlKey || e.metaKey) && e.key === 'b' && selectedIds.length > 0) {
        e.preventDefault();
        setIsBackupDialogOpen(true);
      }

      // Ctrl/Cmd + Shift + A: Archive selected
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'A' && selectedIds.length > 0) {
        e.preventDefault();
        setIsArchiveDialogOpen(true);
      }

      // Ctrl/Cmd + G: Toggle grid/list view
      if ((e.ctrlKey || e.metaKey) && e.key === 'g') {
        e.preventDefault();
        setDisplayView(prev => prev === 'grid' ? 'list' : 'grid');
        toast({ title: `Switched to ${displayView === 'grid' ? 'list' : 'grid'} view` });
      }

      // Ctrl/Cmd + / or ?: Show keyboard shortcuts
      if ((e.ctrlKey || e.metaKey) && (e.key === '/' || e.key === '?')) {
        e.preventDefault();
        setIsShortcutsDialogOpen(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [filteredFiles, selectedIds, isLoading, simulateScan, displayView, toast, exportToCSV]);

  return (
    <div className={`min-h-screen bg-[#f0f2f5] dark:bg-[#0a0a0a] flex flex-col transition-all duration-500 ${viewMode === 'mobile' ? 'items-center justify-center p-4' : ''}`}>
      
      {/* Platform Switcher */}
      <div className="fixed top-4 right-4 z-50 flex bg-white/80 dark:bg-black/80 backdrop-blur-md p-1 rounded-full border shadow-xl print:hidden">
        <Button 
          variant={viewMode === 'windows' ? 'default' : 'ghost'} 
          size="sm" 
          onClick={() => setViewMode('windows')}
          className="rounded-full gap-2"
          data-testid="button-view-windows"
        >
          <Monitor className="w-4 h-4" />
          Windows
        </Button>
        <Button 
          variant={viewMode === 'mobile' ? 'default' : 'ghost'} 
          size="sm" 
          onClick={() => setViewMode('mobile')}
          className="rounded-full gap-2"
          data-testid="button-view-mobile"
        >
          <Smartphone className="w-4 h-4" />
          Mobile
        </Button>
      </div>

      <div className={`bg-background transition-all duration-500 overflow-hidden shadow-2xl relative ${
        viewMode === 'mobile' 
          ? 'w-[375px] h-[812px] rounded-[3rem] border-[8px] border-slate-900' 
          : 'flex flex-col w-full h-screen'
      }`}>
        
        {/* Windows Custom Title Bar */}
        {viewMode === 'windows' && (
          <div className="h-8 bg-[#f8f9fa] dark:bg-[#111] border-b flex items-center justify-between px-3 select-none print:hidden">
            <div className="flex items-center gap-2">
              <LayoutGrid className="w-3.5 h-3.5 text-blue-600" />
              <span className="text-[11px] font-medium text-muted-foreground">FileSweeper v1.0.1</span>
            </div>
            <div className="flex items-center -mr-3 h-full">
              <button className="h-full px-4 hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
                <Minus className="w-3 h-3" />
              </button>
              <button className="h-full px-4 hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
                <Square className="w-2.5 h-2.5 opacity-60" />
              </button>
              <button className="h-full px-4 hover:bg-red-500 hover:text-white transition-colors">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        <div className={`flex flex-1 overflow-hidden ${viewMode === 'mobile' ? 'flex-col' : 'flex-row'}`}>
          {/* Windows Sidebar */}
          {viewMode === 'windows' && (
            <aside className="w-80 border-r bg-[#f8f9fa] dark:bg-[#111] p-6 h-full flex flex-col print:hidden">
              <div className="mb-8 flex items-center gap-2">
                <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center">
                  <LayoutGrid className="w-5 h-5 text-white" />
                </div>
                <h1 className="font-display font-bold text-xl tracking-tight">FileSweeper <span className="text-xs font-normal text-muted-foreground">v1.0.1</span></h1>
              </div>
              <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar">
                <Filters 
                  ageType={ageType}
                  setAgeType={setAgeType}
                  ageValue={ageValue}
                  setAgeValue={setAgeValue}
                  minSizeMB={minSizeMB}
                  setMinSizeMB={setMinSizeMB}
                  selectedTypes={selectedTypes}
                  setSelectedTypes={setSelectedTypes}
                  selectedPath={selectedPath}
                  setSelectedPath={setSelectedPath}
                  onReset={handleResetFilters}
                  onScan={simulateScan}
                  sourceType={sourceType}
                  setSourceType={setSourceType}
                  googleDriveConnected={googleDriveStatus?.connected ?? false}
                  dropboxConnected={dropboxStatus?.connected ?? false}
                  oneDriveConnected={oneDriveStatus?.connected ?? false}
                  recentScans={recentScans}
                  onLoadScan={loadPreviousScan}
                  currentScanId={currentSession?.id}
                />
              </div>
            </aside>
          )}

          {/* Main Interface */}
          <main className="flex-1 flex flex-col h-full overflow-hidden bg-background relative">
            {/* Header */}
            <header className={`h-16 border-b flex items-center justify-between px-6 bg-card/80 backdrop-blur-md z-10 sticky top-0 print:hidden`}>
              <div className="flex items-center gap-4 flex-1">
                {viewMode === 'mobile' ? (
                  <Sheet>
                    <SheetTrigger asChild>
                      <Button variant="ghost" size="icon" className="rounded-full" data-testid="button-menu">
                        <Menu className="w-5 h-5" />
                      </Button>
                    </SheetTrigger>
                    <SheetContent side="left" className="w-[300px] p-6 pt-12 overflow-y-auto">
                      <Filters 
                        ageType={ageType}
                        setAgeType={setAgeType}
                        ageValue={ageValue}
                        setAgeValue={setAgeValue}
                        minSizeMB={minSizeMB}
                        setMinSizeMB={setMinSizeMB}
                        selectedTypes={selectedTypes}
                        setSelectedTypes={setSelectedTypes}
                        selectedPath={selectedPath}
                        setSelectedPath={setSelectedPath}
                        onReset={handleResetFilters}
                        onScan={simulateScan}
                        sourceType={sourceType}
                        setSourceType={setSourceType}
                        googleDriveConnected={googleDriveStatus?.connected ?? false}
                        dropboxConnected={dropboxStatus?.connected ?? false}
                        oneDriveConnected={oneDriveStatus?.connected ?? false}
                        recentScans={recentScans}
                        onLoadScan={loadPreviousScan}
                        currentScanId={currentSession?.id}
                      />
                    </SheetContent>
                  </Sheet>
                ) : null}

                <div className="relative max-w-md w-full">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input 
                    placeholder="Search files..." 
                    className="pl-9 bg-muted/50 border-0 h-9 rounded-full focus-visible:ring-1 focus-visible:ring-primary"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    data-testid="input-search"
                  />
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                {/* View Toggle */}
                <div className="flex items-center border rounded-full p-0.5 bg-muted/50">
                  <Button 
                    variant={displayView === 'grid' ? 'secondary' : 'ghost'} 
                    size="icon" 
                    className="h-7 w-7 rounded-full"
                    onClick={() => setDisplayView('grid')}
                    data-testid="button-view-grid"
                  >
                    <LayoutGrid className="w-3.5 h-3.5" />
                  </Button>
                  <Button 
                    variant={displayView === 'list' ? 'secondary' : 'ghost'} 
                    size="icon" 
                    className="h-7 w-7 rounded-full"
                    onClick={() => setDisplayView('list')}
                    data-testid="button-view-list"
                  >
                    <List className="w-3.5 h-3.5" />
                  </Button>
                </div>

                {/* Export Dropdown */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="rounded-full"
                      disabled={filteredFiles.length === 0}
                      data-testid="button-export"
                    >
                      <Share2 className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48">
                    <DropdownMenuLabel>Export Scan Results</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={exportToCSV} data-testid="export-csv">
                      <FileSpreadsheet className="w-4 h-4 mr-2" />
                      Export as CSV
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={exportToTXT} data-testid="export-txt">
                      <FileText className="w-4 h-4 mr-2" />
                      Export as TXT
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={exportToXLSX} data-testid="export-xlsx">
                      <FileSpreadsheet className="w-4 h-4 mr-2 text-green-600" />
                      Export as Excel
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={exportToPDF} data-testid="export-pdf">
                      <FileType className="w-4 h-4 mr-2 text-red-600" />
                      Export as PDF
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>

                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={simulateScan} 
                  disabled={isLoading} 
                  className="rounded-full"
                  data-testid="button-scan"
                >
                  <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
                </Button>

                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => setIsShortcutsDialogOpen(true)}
                  className="rounded-full"
                  title="Keyboard shortcuts (Ctrl+/)"
                  data-testid="button-shortcuts"
                >
                  <Keyboard className="w-4 h-4" />
                </Button>

                {/* User Profile / Auth */}
                {isAuthLoading ? (
                  <div className="w-8 h-8 rounded-full bg-muted animate-pulse" />
                ) : isLoggedIn && user ? (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="rounded-full relative" data-testid="button-user-menu">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={user.profileImageUrl || undefined} alt={user.firstName || "User"} />
                          <AvatarFallback className="text-xs bg-primary text-primary-foreground">
                            {user.firstName?.[0] || user.email?.[0] || "U"}
                          </AvatarFallback>
                        </Avatar>
                        {user.role === "admin" && (
                          <div className="absolute -bottom-0.5 -right-0.5 bg-yellow-500 rounded-full p-0.5">
                            <Shield className="w-2.5 h-2.5 text-white" />
                          </div>
                        )}
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-56">
                      <DropdownMenuLabel className="font-normal">
                        <div className="flex flex-col space-y-1">
                          <p className="text-sm font-medium">{user.firstName} {user.lastName}</p>
                          <p className="text-xs text-muted-foreground">{user.email}</p>
                          {user.role === "admin" && (
                            <span className="text-[10px] font-semibold uppercase text-yellow-600 flex items-center gap-1">
                              <Shield className="w-3 h-3" /> Admin
                            </span>
                          )}
                        </div>
                      </DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem asChild>
                        <a href="/api/logout" className="cursor-pointer text-red-600">
                          <LogOut className="w-4 h-4 mr-2" />
                          Sign Out
                        </a>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                ) : (
                  <Button className="rounded-full gap-2 bg-primary hover:bg-primary/90 text-primary-foreground shadow-md px-5" asChild data-testid="button-login">
                    <a href="/api/login">
                      <LogIn className="w-4 h-4" />
                      Sign in with Replit
                    </a>
                  </Button>
                )}
              </div>
            </header>

            {/* Scrollable Content */}
            <div className="flex-1 overflow-y-auto p-4 md:p-6 custom-scrollbar print:p-0">
              <div className="max-w-6xl mx-auto space-y-6">
                {/* Login Banner for Cloud Features */}
                {!isLoggedIn && (sourceType === 'google-drive' || sourceType === 'dropbox' || sourceType === 'onedrive') && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-pink-500/10 border border-blue-500/20 rounded-xl p-4 flex items-center justify-between gap-4"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center">
                        <LogIn className="w-5 h-5 text-blue-500" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-sm">Sign in to scan {sourceType === 'google-drive' ? 'Google Drive' : sourceType === 'dropbox' ? 'Dropbox' : 'OneDrive'}</h3>
                        <p className="text-xs text-muted-foreground">Connect your account to access cloud files</p>
                      </div>
                    </div>
                    <Button className="rounded-full gap-2 bg-blue-600 hover:bg-blue-700 text-white shadow-lg" asChild>
                      <a href="/api/login">
                        <LogIn className="w-4 h-4" />
                        Sign in with Replit
                      </a>
                    </Button>
                  </motion.div>
                )}

                <div className="flex flex-col gap-1">
                  <StatsCards files={filteredFiles} selectedCount={selectedIds.length} />
                  <div className="px-1 text-[10px] font-mono text-muted-foreground">
                    Current: {selectedPath}
                  </div>
                </div>

                <div className="flex items-center justify-between px-1 print:hidden">
                  <h2 className="text-lg font-display font-semibold flex items-center gap-2">
                    Files
                    <span className="text-xs font-sans font-medium text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
                      {filteredFiles.length}
                    </span>
                  </h2>
                  <Button variant="ghost" size="sm" onClick={handleSelectAll} className="text-xs h-7 rounded-full" data-testid="button-select-all">
                    {selectedIds.length === filteredFiles.length && filteredFiles.length > 0 ? "Deselect" : "Select All"}
                  </Button>
                </div>

                {!currentSession && !isLoading ? (
                  <div className="flex flex-col items-center justify-center h-48 gap-4 border-2 border-dashed rounded-xl">
                    <div className="text-center">
                      <h3 className="text-lg font-medium">Start a Scan</h3>
                      <p className="text-sm text-muted-foreground mt-1">Click the scan button to find files</p>
                    </div>
                    <Button onClick={simulateScan} className="gap-2 rounded-full" data-testid="button-start-scan">
                      <RefreshCw className="w-4 h-4" />
                      Scan Now
                    </Button>
                  </div>
                ) : isLoading ? (
                  <div className="flex flex-col items-center justify-center h-48 gap-3">
                    <div className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full animate-spin" />
                    <p className="text-xs text-muted-foreground">Scanning {selectedPath}...</p>
                  </div>
                ) : (
                  <FileGrid 
                    files={filteredFiles} 
                    selectedIds={selectedIds} 
                    onToggleSelect={handleToggleSelect}
                    viewMode={displayView}
                  />
                )}
              </div>
            </div>

            {/* Success Overlay Feedback */}
            <AnimatePresence>
              {showSuccessOverlay && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className="absolute inset-0 z-50 flex items-center justify-center bg-background/60 backdrop-blur-sm pointer-events-none print:hidden"
                >
                  <div className="bg-card border shadow-2xl rounded-2xl p-8 flex flex-col items-center gap-4 max-w-[320px] text-center pointer-events-auto">
                    <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center text-green-500">
                      <CheckCircle2 className="w-10 h-10" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold font-display">Completed!</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        Successfully {lastAction?.name.toLowerCase()}ed {lastAction?.count} files.
                      </p>
                    </div>
                    <div className="flex flex-col w-full gap-2 mt-2">
                      <Button variant="outline" size="sm" className="w-full rounded-full gap-2" onClick={() => setIsReportDialogOpen(true)} data-testid="button-view-report">
                        <FileText className="w-4 h-4" />
                        View Verbose Report
                      </Button>
                      <Button variant="ghost" size="sm" className="w-full rounded-full" onClick={() => setShowSuccessOverlay(false)} data-testid="button-close-overlay">
                        Close
                      </Button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Action Bar */}
            <AnimatePresence>
              {selectedIds.length > 0 && (
                <motion.div 
                  initial={{ y: 100, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: 100, opacity: 0 }}
                  className={`absolute ${viewMode === 'mobile' ? 'bottom-12' : 'bottom-6'} left-0 right-0 px-6 flex justify-center z-50 pointer-events-none print:hidden`}
                >
                  <div className="bg-[#1a1a1a] text-white rounded-2xl shadow-2xl px-4 py-2 flex items-center gap-2 pointer-events-auto border border-white/10">
                    <div className="px-2 text-xs font-medium border-r border-white/10 mr-1" data-testid="text-selected-count">
                      {selectedIds.length}
                    </div>
                    <div className="flex items-center">
                      <Button variant="ghost" size="sm" onClick={() => setIsBackupDialogOpen(true)} className="h-8 px-2 text-white hover:bg-white/10 rounded-lg" data-testid="button-backup">
                        <Download className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => confirmAction("Archive")} className="h-8 px-2 text-white hover:bg-white/10 rounded-lg" data-testid="button-archive">
                        <Archive className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="sm" onClick={() => confirmAction("Delete Permanently")} className="h-8 px-2 text-red-400 hover:bg-red-500/10 rounded-lg" data-testid="button-delete">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </main>
        </div>

        {/* Mobile Home Indicator */}
        {viewMode === 'mobile' && (
          <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-32 h-1 bg-slate-800 rounded-full" />
        )}
      </div>

      {/* Confirmation Dialogs */}
      {/* Delete Dialog with Destination */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent className="max-w-md">
          <AlertDialogHeader>
            <div className="flex items-center gap-2 text-red-500 mb-2">
              <AlertTriangle className="w-5 h-5" />
              <AlertDialogTitle>Delete Permanently?</AlertDialogTitle>
            </div>
            <AlertDialogDescription>
              This will move {selectedIds.length} file{selectedIds.length === 1 ? '' : 's'} to the recycle bin.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-3 py-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-medium text-muted-foreground">Recycle Bin Location</label>
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-6 text-xs gap-1"
                onClick={() => setUseCustomDeletePath(!useCustomDeletePath)}
                data-testid="toggle-custom-delete-path"
              >
                <FolderOpen className="w-3 h-3" />
                {useCustomDeletePath ? "Use Preset" : "Browse Custom"}
              </Button>
            </div>
            {useCustomDeletePath ? (
              <div className="flex items-center gap-2 p-2 bg-muted/50 rounded-md border">
                <Trash2 className="w-4 h-4 text-red-500 shrink-0" />
                <Input 
                  value={deleteDestination}
                  onChange={(e) => setDeleteDestination(e.target.value)}
                  placeholder="Enter custom path..."
                  className="h-7 text-xs border-0 bg-transparent p-0 focus-visible:ring-0"
                  data-testid="input-delete-destination"
                />
              </div>
            ) : (
              <Select value={deleteDestination} onValueChange={setDeleteDestination}>
                <SelectTrigger className="w-full" data-testid="select-delete-destination">
                  <SelectValue placeholder="Select destination" />
                </SelectTrigger>
                <SelectContent>
                  {deletePresets.map((path) => (
                    <SelectItem key={path} value={path} data-testid={`delete-preset-${path.replace(/[^a-zA-Z0-9]/g, '-')}`}>
                      <div className="flex items-center gap-2">
                        <Trash2 className="w-3 h-3 text-red-500" />
                        {path}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-full" data-testid="button-cancel-delete">Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => performAction("Delete Permanently", deleteDestination)}
              className="bg-red-600 hover:bg-red-700 text-white rounded-full"
              data-testid="button-confirm-delete"
            >
              Confirm Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Archive Dialog with Destination */}
      <AlertDialog open={isArchiveDialogOpen} onOpenChange={setIsArchiveDialogOpen}>
        <AlertDialogContent className="max-w-md">
          <AlertDialogHeader>
            <div className="flex items-center gap-2 text-blue-500 mb-2">
              <FolderArchive className="w-5 h-5" />
              <AlertDialogTitle>Archive Files?</AlertDialogTitle>
            </div>
            <AlertDialogDescription>
              Move {selectedIds.length} file{selectedIds.length === 1 ? '' : 's'} to compressed archive storage.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-3 py-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-medium text-muted-foreground">Archive Destination</label>
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-6 text-xs gap-1"
                onClick={() => setUseCustomArchivePath(!useCustomArchivePath)}
                data-testid="toggle-custom-archive-path"
              >
                <FolderOpen className="w-3 h-3" />
                {useCustomArchivePath ? "Use Preset" : "Browse Custom"}
              </Button>
            </div>
            {useCustomArchivePath ? (
              <div className="flex items-center gap-2 p-2 bg-muted/50 rounded-md border">
                <FolderArchive className="w-4 h-4 text-blue-500 shrink-0" />
                <Input 
                  value={archiveDestination}
                  onChange={(e) => setArchiveDestination(e.target.value)}
                  placeholder="Enter custom path..."
                  className="h-7 text-xs border-0 bg-transparent p-0 focus-visible:ring-0"
                  data-testid="input-archive-destination"
                />
              </div>
            ) : (
              <Select value={archiveDestination} onValueChange={setArchiveDestination}>
                <SelectTrigger className="w-full" data-testid="select-archive-destination">
                  <SelectValue placeholder="Select destination" />
                </SelectTrigger>
                <SelectContent>
                  {archivePresets.map((path) => (
                    <SelectItem key={path} value={path} data-testid={`archive-preset-${path.replace(/[^a-zA-Z0-9]/g, '-')}`}>
                      <div className="flex items-center gap-2">
                        <FolderArchive className="w-3 h-3 text-blue-500" />
                        {path}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-full" data-testid="button-cancel-archive">Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => performAction("Archive", archiveDestination)}
              className="bg-blue-600 hover:bg-blue-700 text-white rounded-full"
              data-testid="button-confirm-archive"
            >
              Confirm Archive
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Backup Dialog with Destination */}
      <AlertDialog open={isBackupDialogOpen} onOpenChange={setIsBackupDialogOpen}>
        <AlertDialogContent className="max-w-md">
          <AlertDialogHeader>
            <div className="flex items-center gap-2 text-green-500 mb-2">
              <Download className="w-5 h-5" />
              <AlertDialogTitle>Backup Files?</AlertDialogTitle>
            </div>
            <AlertDialogDescription>
              Create a backup copy of {selectedIds.length} file{selectedIds.length === 1 ? '' : 's'}.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-3 py-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-medium text-muted-foreground">Backup Destination</label>
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-6 text-xs gap-1"
                onClick={() => setUseCustomBackupPath(!useCustomBackupPath)}
                data-testid="toggle-custom-backup-path"
              >
                <FolderOpen className="w-3 h-3" />
                {useCustomBackupPath ? "Use Preset" : "Browse Custom"}
              </Button>
            </div>
            {useCustomBackupPath ? (
              <div className="flex items-center gap-2 p-2 bg-muted/50 rounded-md border">
                <Download className="w-4 h-4 text-green-500 shrink-0" />
                <Input 
                  value={backupDestination}
                  onChange={(e) => setBackupDestination(e.target.value)}
                  placeholder="Enter custom path..."
                  className="h-7 text-xs border-0 bg-transparent p-0 focus-visible:ring-0"
                  data-testid="input-backup-destination"
                />
              </div>
            ) : (
              <Select value={backupDestination} onValueChange={setBackupDestination}>
                <SelectTrigger className="w-full" data-testid="select-backup-destination">
                  <SelectValue placeholder="Select destination" />
                </SelectTrigger>
                <SelectContent>
                  {backupPresets.map((path) => (
                    <SelectItem key={path} value={path} data-testid={`backup-preset-${path.replace(/[^a-zA-Z0-9]/g, '-')}`}>
                      <div className="flex items-center gap-2">
                        <Download className="w-3 h-3 text-green-500" />
                        {path}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-full" data-testid="button-cancel-backup">Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => { performAction("Backup", backupDestination); setIsBackupDialogOpen(false); }}
              className="bg-green-600 hover:bg-green-700 text-white rounded-full"
              data-testid="button-confirm-backup"
            >
              Confirm Backup
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Verbose Report Dialog */}
      <Dialog open={isReportDialogOpen} onOpenChange={setIsReportDialogOpen}>
        <DialogContent className="max-w-2xl h-[80vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary" />
              Verbose Action Report
            </DialogTitle>
            <DialogDescription>
              Details of the {lastAction?.count} files {lastAction?.name.toLowerCase()}ed on {format(new Date(), 'PPpp')}.
            </DialogDescription>
          </DialogHeader>
          
          <ScrollArea className="flex-1 mt-4 border rounded-lg bg-muted/30 p-4">
            <div className="space-y-4 font-mono text-xs">
              <div className="pb-2 border-b font-bold text-sm">SUMMARY</div>
              <div>Action: {lastAction?.name}</div>
              <div>Count: {lastAction?.count} files</div>
              <div>Timestamp: {format(new Date(), 'yyyy-MM-dd HH:mm:ss')}</div>
              
              <div className="pt-4 pb-2 border-b font-bold text-sm">VERBOSE LOG</div>
              {lastAction?.files.map((file, i) => (
                <div key={file.id} className="space-y-1">
                  <div className="text-primary">{i + 1}. {file.name}</div>
                  <div className="pl-4 opacity-70">Type: {file.type.toUpperCase()} ({file.extension})</div>
                  <div className="pl-4 opacity-70">Path: {file.path}</div>
                  <div className="pl-4 opacity-70">Size: {formatBytes(file.size)}</div>
                  <div className="pl-4 opacity-70">Last Modified: {format(file.lastModified, 'yyyy-MM-dd HH:mm:ss')}</div>
                  <div className="h-px bg-border/50 my-2" />
                </div>
              ))}
            </div>
          </ScrollArea>

          <DialogFooter className="flex-row justify-between sm:justify-between mt-6">
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="rounded-full gap-2" onClick={handlePrint} data-testid="button-print">
                <Printer className="w-4 h-4" />
                Print
              </Button>
              <Button variant="outline" size="sm" className="rounded-full gap-2" onClick={handleDownloadReport} data-testid="button-download-report">
                <FileDown className="w-4 h-4" />
                Save .txt
              </Button>
            </div>
            <Button size="sm" className="rounded-full" onClick={() => setIsReportDialogOpen(false)} data-testid="button-close-report">
              Close Report
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Keyboard Shortcuts Dialog */}
      <Dialog open={isShortcutsDialogOpen} onOpenChange={setIsShortcutsDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Keyboard className="w-5 h-5 text-primary" />
              Keyboard Shortcuts
            </DialogTitle>
            <DialogDescription>
              Quick actions to boost your productivity
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 py-4">
            <div className="flex justify-between items-center">
              <span className="text-sm">Select all files</span>
              <kbd className="px-2 py-1 text-xs bg-muted rounded border">Ctrl + A</kbd>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Deselect all</span>
              <kbd className="px-2 py-1 text-xs bg-muted rounded border">Ctrl + D</kbd>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Start scan</span>
              <kbd className="px-2 py-1 text-xs bg-muted rounded border">Ctrl + R</kbd>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Export to CSV</span>
              <kbd className="px-2 py-1 text-xs bg-muted rounded border">Ctrl + E</kbd>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Toggle grid/list view</span>
              <kbd className="px-2 py-1 text-xs bg-muted rounded border">Ctrl + G</kbd>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Backup selected</span>
              <kbd className="px-2 py-1 text-xs bg-muted rounded border">Ctrl + B</kbd>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Archive selected</span>
              <kbd className="px-2 py-1 text-xs bg-muted rounded border">Ctrl + Shift + A</kbd>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Delete selected</span>
              <kbd className="px-2 py-1 text-xs bg-muted rounded border">Delete</kbd>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Clear selection</span>
              <kbd className="px-2 py-1 text-xs bg-muted rounded border">Escape</kbd>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm">Show shortcuts</span>
              <kbd className="px-2 py-1 text-xs bg-muted rounded border">Ctrl + /</kbd>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setIsShortcutsDialogOpen(false)} className="rounded-full" data-testid="button-close-shortcuts">
              Got it!
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
