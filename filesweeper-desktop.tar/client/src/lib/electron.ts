declare global {
  interface Window {
    electronAPI?: {
      minimizeWindow: () => Promise<void>;
      maximizeWindow: () => Promise<void>;
      closeWindow: () => Promise<void>;
      selectDirectory: () => Promise<string | null>;
      scanDirectory: (dirPath: string, options: ScanOptions) => Promise<ElectronFile[]>;
      deleteFiles: (filePaths: string[], toRecycleBin?: boolean) => Promise<FileActionResult[]>;
      copyFiles: (filePaths: string[], destination: string) => Promise<FileActionResult[]>;
      moveFiles: (filePaths: string[], destination: string) => Promise<FileActionResult[]>;
      getDrives: () => Promise<string[]>;
      isElectron: boolean;
    };
  }
}

export interface ScanOptions {
  minAgeDays?: number;
  minSizeMB?: number;
  fileTypes?: string[];
}

export interface ElectronFile {
  id: string;
  name: string;
  path: string;
  size: number;
  type: string;
  extension: string;
  lastModified: string;
  createdAt: string;
}

export interface FileActionResult {
  path: string;
  success: boolean;
  error?: string;
  destination?: string;
}

export function isElectron(): boolean {
  return typeof window !== 'undefined' && !!window.electronAPI?.isElectron;
}

export async function selectDirectory(): Promise<string | null> {
  if (!isElectron()) return null;
  return window.electronAPI!.selectDirectory();
}

export async function scanDirectory(dirPath: string, options: ScanOptions = {}): Promise<ElectronFile[]> {
  if (!isElectron()) return [];
  return window.electronAPI!.scanDirectory(dirPath, options);
}

export async function deleteFiles(filePaths: string[], toRecycleBin = true): Promise<FileActionResult[]> {
  if (!isElectron()) return [];
  return window.electronAPI!.deleteFiles(filePaths, toRecycleBin);
}

export async function copyFiles(filePaths: string[], destination: string): Promise<FileActionResult[]> {
  if (!isElectron()) return [];
  return window.electronAPI!.copyFiles(filePaths, destination);
}

export async function moveFiles(filePaths: string[], destination: string): Promise<FileActionResult[]> {
  if (!isElectron()) return [];
  return window.electronAPI!.moveFiles(filePaths, destination);
}

export async function getDrives(): Promise<string[]> {
  if (!isElectron()) return [];
  return window.electronAPI!.getDrives();
}

export function minimizeWindow(): void {
  if (isElectron()) {
    window.electronAPI!.minimizeWindow();
  }
}

export function maximizeWindow(): void {
  if (isElectron()) {
    window.electronAPI!.maximizeWindow();
  }
}

export function closeWindow(): void {
  if (isElectron()) {
    window.electronAPI!.closeWindow();
  }
}
