import { subDays, subMonths, format } from "date-fns";

export type FileType = "image" | "video" | "document" | "archive" | "audio" | "other";

export interface FileItem {
  id: string;
  name: string;
  path: string;
  size: number; // bytes
  type: FileType;
  extension: string;
  lastModified: Date;
  lastAccessed: Date;
  previewUrl?: string;
  actionTaken?: string;
}

const EXTENSIONS: Record<FileType, string[]> = {
  image: ["jpg", "png", "webp", "svg", "raw"],
  video: ["mp4", "mov", "avi", "mkv"],
  document: ["pdf", "docx", "txt", "xlsx", "ppt"],
  archive: ["zip", "tar", "gz", "rar"],
  audio: ["mp3", "wav", "aac"],
  other: ["iso", "dmg", "exe", "dat"]
};

const FOLDERS = ["Downloads", "Documents", "Projects", "Desktop", "Photos", "Work"];

function getRandomInt(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function getRandomItem<T>(arr: T[]): T {
  return arr[getRandomInt(0, arr.length - 1)];
}

export function generateMockFiles(count: number = 50): FileItem[] {
  return Array.from({ length: count }).map((_, i) => {
    const type = getRandomItem(Object.keys(EXTENSIONS)) as FileType;
    const ext = getRandomItem(EXTENSIONS[type]);
    const folder = getRandomItem(FOLDERS);
    const name = `file_${getRandomInt(1000, 9999)}.${ext}`;
    
    // Generate dates between 1 day ago and 2 years ago
    const daysAgo = getRandomInt(1, 730);
    const modifiedDate = subDays(new Date(), daysAgo);
    const accessedDate = subDays(modifiedDate, getRandomInt(0, 30)); // Accessed slightly after modification

    // Size: bias towards larger files for video/archive
    let sizeBase = 1024 * 1024; // 1MB
    if (type === "video" || type === "archive") sizeBase *= 500;
    if (type === "document") sizeBase /= 10;
    
    const size = getRandomInt(sizeBase * 0.1, sizeBase * 2);

    // Mock preview URLs
    let previewUrl: string | undefined;
    if (type === "image") {
      previewUrl = `https://picsum.photos/seed/${i}/400/300`;
    }

    return {
      id: `file-${i}`,
      name,
      path: `/${folder}/${name}`,
      size,
      type,
      extension: ext,
      lastModified: modifiedDate,
      lastAccessed: accessedDate,
      previewUrl
    };
  });
}

export function formatBytes(bytes: number, decimals = 2) {
  if (!+bytes) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
}
