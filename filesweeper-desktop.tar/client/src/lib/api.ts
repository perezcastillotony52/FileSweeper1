import { apiRequest } from "./queryClient";
import type { FileItem, FileType } from "./mock-data";

// Types for API responses
export interface ScanSession {
  id: string;
  scanPath: string;
  minAgeDays: number;
  minSizeMB: number;
  fileTypes: string;
  totalFiles: number;
  totalSizeMB: number;
  createdAt: string;
}

export interface ScannedFile {
  id: string;
  sessionId: string;
  name: string;
  path: string;
  size: number;
  type: string;
  extension: string;
  lastModified: string;
  lastAccessed: string;
  previewUrl: string | null;
  isSelected: boolean;
  actionTaken: string | null;
  createdAt: string;
}

export interface FileAction {
  id: string;
  fileId: string;
  sessionId: string;
  actionType: string;
  fileName: string;
  filePath: string;
  fileSize: number;
  success: boolean;
  createdAt: string;
}

// Convert ScannedFile to FileItem for frontend compatibility
export function toFileItem(file: ScannedFile): FileItem {
  return {
    id: file.id,
    name: file.name,
    path: file.path,
    size: file.size,
    type: file.type as FileType,
    extension: file.extension,
    lastModified: new Date(file.lastModified),
    lastAccessed: new Date(file.lastAccessed),
    previewUrl: file.previewUrl || undefined,
    actionTaken: file.actionTaken || undefined,
  };
}

// Scan Sessions API
export async function createScanSession(data: {
  scanPath: string;
  minAgeDays: number;
  minSizeMB: number;
  fileTypes: string;
}): Promise<ScanSession> {
  const res = await apiRequest("POST", "/api/scans", data);
  return res.json();
}

export async function getAllScanSessions(): Promise<ScanSession[]> {
  const res = await apiRequest("GET", "/api/scans");
  return res.json();
}

export async function getScanSession(id: string): Promise<ScanSession> {
  const res = await apiRequest("GET", `/api/scans/${id}`);
  return res.json();
}

export async function updateScanSessionStats(
  id: string,
  totalFiles: number,
  totalSizeMB: number
): Promise<ScanSession> {
  const res = await apiRequest("PATCH", `/api/scans/${id}/stats`, { totalFiles, totalSizeMB });
  return res.json();
}

// Scanned Files API
export async function addFilesToScan(sessionId: string, files: any[]): Promise<ScannedFile[]> {
  const res = await apiRequest("POST", `/api/scans/${sessionId}/files`, { files });
  return res.json();
}

export async function getFilesBySession(sessionId: string): Promise<ScannedFile[]> {
  const res = await apiRequest("GET", `/api/scans/${sessionId}/files`);
  return res.json();
}

export async function updateFileSelection(fileId: string, isSelected: boolean): Promise<ScannedFile> {
  const res = await apiRequest("PATCH", `/api/files/${fileId}/select`, { isSelected });
  return res.json();
}

export async function bulkUpdateFileSelection(fileIds: string[], isSelected: boolean): Promise<void> {
  await apiRequest("PATCH", "/api/files/bulk-select", { fileIds, isSelected });
}

// File Actions API
export async function performFileAction(
  fileIds: string[],
  actionType: "backup" | "archive" | "delete",
  sessionId: string,
  destination?: string
): Promise<{ success: boolean; actions: FileAction[]; message: string }> {
  const res = await apiRequest("POST", "/api/files/action", { fileIds, actionType, sessionId, destination });
  return res.json();
}

export async function getAllActions(): Promise<FileAction[]> {
  const res = await apiRequest("GET", "/api/actions");
  return res.json();
}

export async function getActionsBySession(sessionId: string): Promise<FileAction[]> {
  const res = await apiRequest("GET", `/api/scans/${sessionId}/actions`);
  return res.json();
}

// Cloud Storage API
export interface GoogleDriveStatus {
  connected: boolean;
}

export interface CloudFile {
  name: string;
  path: string;
  size: number;
  type: string;
  extension: string;
  lastModified: string;
  lastAccessed: string;
  previewUrl: string | null;
  cloudId: string;
  cloudSource: 'google-drive';
}

export async function getGoogleDriveStatus(): Promise<GoogleDriveStatus> {
  const res = await apiRequest("GET", "/api/cloud/google-drive/status");
  return res.json();
}

export async function scanGoogleDrive(folderId?: string): Promise<CloudFile[]> {
  const url = folderId 
    ? `/api/cloud/google-drive/scan?folderId=${encodeURIComponent(folderId)}`
    : "/api/cloud/google-drive/scan";
  const res = await apiRequest("GET", url);
  return res.json();
}

// Dropbox API
export interface DropboxStatus {
  connected: boolean;
}

export async function getDropboxStatus(): Promise<DropboxStatus> {
  const res = await apiRequest("GET", "/api/cloud/dropbox/status");
  return res.json();
}

export async function scanDropbox(path?: string): Promise<CloudFile[]> {
  const url = path 
    ? `/api/cloud/dropbox/scan?path=${encodeURIComponent(path)}`
    : "/api/cloud/dropbox/scan";
  const res = await apiRequest("GET", url);
  return res.json();
}

// OneDrive API
export interface OneDriveStatus {
  connected: boolean;
}

export async function getOneDriveStatus(): Promise<OneDriveStatus> {
  const res = await apiRequest("GET", "/api/cloud/onedrive/status");
  return res.json();
}

export async function scanOneDrive(folderId?: string): Promise<CloudFile[]> {
  const url = folderId 
    ? `/api/cloud/onedrive/scan?folderId=${encodeURIComponent(folderId)}`
    : "/api/cloud/onedrive/scan";
  const res = await apiRequest("GET", url);
  return res.json();
}
