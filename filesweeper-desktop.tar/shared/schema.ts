import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Export auth models
export * from "./models/auth";

// File types enum
export const fileTypes = ["image", "video", "document", "archive", "audio", "other"] as const;
export type FileType = typeof fileTypes[number];

// Action types enum  
export const actionTypes = ["backup", "archive", "delete"] as const;
export type ActionType = typeof actionTypes[number];

// Scan sessions - represents a single scan operation
export const scanSessions = pgTable("scan_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  scanPath: text("scan_path").notNull(),
  minAgeDays: integer("min_age_days").notNull().default(30),
  minSizeMB: integer("min_size_mb").notNull().default(0),
  fileTypes: text("file_types").notNull(), // JSON array as string
  totalFiles: integer("total_files").notNull().default(0),
  totalSizeMB: integer("total_size_mb").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertScanSessionSchema = createInsertSchema(scanSessions).omit({
  id: true,
  createdAt: true,
});
export type InsertScanSession = z.infer<typeof insertScanSessionSchema>;
export type ScanSession = typeof scanSessions.$inferSelect;

// Scanned files - files found during a scan
export const scannedFiles = pgTable("scanned_files", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sessionId: varchar("session_id").notNull(),
  name: text("name").notNull(),
  path: text("path").notNull(),
  size: integer("size").notNull(), // bytes
  type: text("type").notNull(), // FileType
  extension: text("extension").notNull(),
  lastModified: timestamp("last_modified").notNull(),
  lastAccessed: timestamp("last_accessed").notNull(),
  previewUrl: text("preview_url"),
  isSelected: boolean("is_selected").notNull().default(false),
  actionTaken: text("action_taken"), // ActionType or null
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertScannedFileSchema = createInsertSchema(scannedFiles, {
  size: z.coerce.number().transform(v => Math.floor(v)),
  lastModified: z.coerce.date(),
  lastAccessed: z.coerce.date(),
}).omit({
  id: true,
  createdAt: true,
});
export type InsertScannedFile = z.infer<typeof insertScannedFileSchema>;
export type ScannedFile = typeof scannedFiles.$inferSelect;

// File actions - history of actions taken on files
export const fileActions = pgTable("file_actions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fileId: varchar("file_id").notNull(),
  sessionId: varchar("session_id").notNull(),
  actionType: text("action_type").notNull(), // ActionType
  fileName: text("file_name").notNull(),
  filePath: text("file_path").notNull(),
  fileSize: integer("file_size").notNull(),
  success: boolean("success").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertFileActionSchema = createInsertSchema(fileActions).omit({
  id: true,
  createdAt: true,
});
export type InsertFileAction = z.infer<typeof insertFileActionSchema>;
export type FileAction = typeof fileActions.$inferSelect;

