// Dropbox Integration - Replit Connector
import { Dropbox } from 'dropbox';

let connectionSettings: any;

async function getAccessToken() {
  if (connectionSettings && connectionSettings.settings.expires_at && new Date(connectionSettings.settings.expires_at).getTime() > Date.now()) {
    return connectionSettings.settings.access_token;
  }
  
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY 
    ? 'repl ' + process.env.REPL_IDENTITY 
    : process.env.WEB_REPL_RENEWAL 
    ? 'depl ' + process.env.WEB_REPL_RENEWAL 
    : null;

  if (!xReplitToken) {
    throw new Error('X_REPLIT_TOKEN not found for repl/depl');
  }

  connectionSettings = await fetch(
    'https://' + hostname + '/api/v2/connection?include_secrets=true&connector_names=dropbox',
    {
      headers: {
        'Accept': 'application/json',
        'X_REPLIT_TOKEN': xReplitToken
      }
    }
  ).then(res => res.json()).then(data => data.items?.[0]);

  const accessToken = connectionSettings?.settings?.access_token || connectionSettings.settings?.oauth?.credentials?.access_token;

  if (!connectionSettings || !accessToken) {
    throw new Error('Dropbox not connected');
  }
  return accessToken;
}

// WARNING: Never cache this client.
// Access tokens expire, so a new client must be created each time.
async function getUncachableDropboxClient() {
  const accessToken = await getAccessToken();
  return new Dropbox({ accessToken });
}

// List folders in Dropbox
export async function listDropboxFolders(path: string = ''): Promise<{ id: string; name: string; path: string }[]> {
  const dbx = await getUncachableDropboxClient();
  const response = await dbx.filesListFolder({ path });
  
  return response.result.entries
    .filter((entry: any) => entry['.tag'] === 'folder')
    .map((folder: any) => ({
      id: folder.id,
      name: folder.name,
      path: folder.path_display || folder.path_lower
    }));
}

// Scan files from Dropbox
export async function scanDropboxFiles(path: string = ''): Promise<any[]> {
  const dbx = await getUncachableDropboxClient();
  const response = await dbx.filesListFolder({ path, recursive: true });
  
  const files = response.result.entries
    .filter((entry: any) => entry['.tag'] === 'file')
    .map((file: any) => {
      const name = file.name;
      const extension = name.includes('.') ? name.split('.').pop()?.toLowerCase() || '' : '';
      const type = getFileType(extension);
      
      return {
        name,
        path: `dropbox://${file.path_display || file.path_lower}`,
        size: file.size || 0,
        type,
        extension,
        lastModified: file.server_modified || new Date().toISOString(),
        lastAccessed: file.client_modified || file.server_modified || new Date().toISOString(),
        previewUrl: null,
        cloudId: file.id,
        cloudSource: 'dropbox' as const
      };
    });

  return files;
}

function getFileType(extension: string): string {
  const imageExts = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg', 'ico'];
  const videoExts = ['mp4', 'avi', 'mov', 'mkv', 'wmv', 'flv', 'webm'];
  const audioExts = ['mp3', 'wav', 'ogg', 'flac', 'aac', 'm4a'];
  const docExts = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'rtf'];
  const archiveExts = ['zip', 'rar', '7z', 'tar', 'gz'];
  
  if (imageExts.includes(extension)) return 'image';
  if (videoExts.includes(extension)) return 'video';
  if (audioExts.includes(extension)) return 'audio';
  if (docExts.includes(extension)) return 'document';
  if (archiveExts.includes(extension)) return 'archive';
  return 'other';
}
