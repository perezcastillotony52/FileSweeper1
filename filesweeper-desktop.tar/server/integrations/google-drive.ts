import { google } from 'googleapis';

let connectionSettings: any;

async function getAccessToken() {
  if (connectionSettings && connectionSettings.settings.expires_at && new Date(connectionSettings.settings.expires_at).getTime() > Date.now()) {
    return connectionSettings.settings.access_token;
  }
  
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY 
    ? 'repl ' + process.env.REPL_IDENTITY 
    : process.env.WEB_REPL_RENEWAL 
    ? 'depl ' + process.env.WEB_REPL_RENEWAL 
    : null;

  if (!xReplitToken) {
    throw new Error('X_REPLIT_TOKEN not found for repl/depl');
  }

  connectionSettings = await fetch(
    'https://' + hostname + '/api/v2/connection?include_secrets=true&connector_names=google-drive',
    {
      headers: {
        'Accept': 'application/json',
        'X_REPLIT_TOKEN': xReplitToken
      }
    }
  ).then(res => res.json()).then(data => data.items?.[0]);

  const accessToken = connectionSettings?.settings?.access_token || connectionSettings.settings?.oauth?.credentials?.access_token;

  if (!connectionSettings || !accessToken) {
    throw new Error('Google Drive not connected');
  }
  return accessToken;
}

export async function getGoogleDriveClient() {
  const accessToken = await getAccessToken();

  const oauth2Client = new google.auth.OAuth2();
  oauth2Client.setCredentials({
    access_token: accessToken
  });

  return google.drive({ version: 'v3', auth: oauth2Client });
}

export interface GoogleDriveFile {
  id: string;
  name: string;
  mimeType: string;
  size: number;
  modifiedTime: Date;
  createdTime: Date;
  webViewLink?: string;
  iconLink?: string;
  parents?: string[];
}

export async function listGoogleDriveFiles(folderId?: string): Promise<GoogleDriveFile[]> {
  const drive = await getGoogleDriveClient();
  
  let query = "trashed = false";
  if (folderId) {
    query += ` and '${folderId}' in parents`;
  }

  const response = await drive.files.list({
    q: query,
    fields: 'files(id, name, mimeType, size, modifiedTime, createdTime, webViewLink, iconLink, parents)',
    pageSize: 100,
    orderBy: 'modifiedTime desc'
  });

  return (response.data.files || []).map(file => ({
    id: file.id || '',
    name: file.name || 'Unknown',
    mimeType: file.mimeType || 'application/octet-stream',
    size: parseInt(file.size || '0', 10),
    modifiedTime: new Date(file.modifiedTime || Date.now()),
    createdTime: new Date(file.createdTime || Date.now()),
    webViewLink: file.webViewLink || undefined,
    iconLink: file.iconLink || undefined,
    parents: file.parents || undefined
  }));
}

export async function listGoogleDriveFolders(): Promise<GoogleDriveFile[]> {
  const drive = await getGoogleDriveClient();
  
  const response = await drive.files.list({
    q: "mimeType = 'application/vnd.google-apps.folder' and trashed = false",
    fields: 'files(id, name, mimeType, modifiedTime, createdTime, parents)',
    pageSize: 50,
    orderBy: 'name'
  });

  return (response.data.files || []).map(file => ({
    id: file.id || '',
    name: file.name || 'Unknown',
    mimeType: file.mimeType || 'application/vnd.google-apps.folder',
    size: 0,
    modifiedTime: new Date(file.modifiedTime || Date.now()),
    createdTime: new Date(file.createdTime || Date.now()),
    parents: file.parents || undefined
  }));
}

function getFileTypeFromMimeType(mimeType: string): string {
  if (mimeType.startsWith('image/')) return 'image';
  if (mimeType.startsWith('video/')) return 'video';
  if (mimeType.startsWith('audio/')) return 'audio';
  if (mimeType.includes('zip') || mimeType.includes('tar') || mimeType.includes('rar') || mimeType.includes('7z') || mimeType.includes('compressed')) return 'archive';
  if (mimeType.includes('document') || mimeType.includes('pdf') || mimeType.includes('text') || mimeType.includes('spreadsheet') || mimeType.includes('presentation')) return 'document';
  return 'other';
}

function getExtensionFromMimeType(mimeType: string, name: string): string {
  const extMatch = name.match(/\.([^.]+)$/);
  if (extMatch) return extMatch[1].toLowerCase();
  
  const mimeExtensions: Record<string, string> = {
    'application/pdf': 'pdf',
    'image/jpeg': 'jpg',
    'image/png': 'png',
    'image/gif': 'gif',
    'video/mp4': 'mp4',
    'audio/mpeg': 'mp3',
    'application/zip': 'zip',
    'text/plain': 'txt',
    'application/vnd.google-apps.document': 'gdoc',
    'application/vnd.google-apps.spreadsheet': 'gsheet',
    'application/vnd.google-apps.presentation': 'gslides',
  };
  
  return mimeExtensions[mimeType] || 'unknown';
}

export async function scanGoogleDriveFiles(folderId?: string) {
  const files = await listGoogleDriveFiles(folderId);
  
  return files
    .filter(f => f.mimeType !== 'application/vnd.google-apps.folder')
    .map(file => ({
      name: file.name,
      path: `gdrive://${folderId || 'root'}/${file.name}`,
      size: file.size,
      type: getFileTypeFromMimeType(file.mimeType),
      extension: getExtensionFromMimeType(file.mimeType, file.name),
      lastModified: file.modifiedTime,
      lastAccessed: file.modifiedTime,
      previewUrl: file.webViewLink || null,
      cloudId: file.id,
      cloudSource: 'google-drive' as const
    }));
}
