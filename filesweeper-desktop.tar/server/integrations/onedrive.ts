// OneDrive Integration - Replit Connector
import { Client } from '@microsoft/microsoft-graph-client';

let connectionSettings: any;

async function getAccessToken() {
  if (connectionSettings && connectionSettings.settings.expires_at && new Date(connectionSettings.settings.expires_at).getTime() > Date.now()) {
    return connectionSettings.settings.access_token;
  }
  
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY 
    ? 'repl ' + process.env.REPL_IDENTITY 
    : process.env.WEB_REPL_RENEWAL 
    ? 'depl ' + process.env.WEB_REPL_RENEWAL 
    : null;

  if (!xReplitToken) {
    throw new Error('X_REPLIT_TOKEN not found for repl/depl');
  }

  connectionSettings = await fetch(
    'https://' + hostname + '/api/v2/connection?include_secrets=true&connector_names=onedrive',
    {
      headers: {
        'Accept': 'application/json',
        'X_REPLIT_TOKEN': xReplitToken
      }
    }
  ).then(res => res.json()).then(data => data.items?.[0]);

  const accessToken = connectionSettings?.settings?.access_token || connectionSettings.settings?.oauth?.credentials?.access_token;

  if (!connectionSettings || !accessToken) {
    throw new Error('OneDrive not connected');
  }
  return accessToken;
}

// WARNING: Never cache this client.
// Access tokens expire, so a new client must be created each time.
async function getUncachableOneDriveClient() {
  const accessToken = await getAccessToken();

  return Client.initWithMiddleware({
    authProvider: {
      getAccessToken: async () => accessToken
    }
  });
}

// List folders in OneDrive
export async function listOneDriveFolders(folderId?: string): Promise<{ id: string; name: string; path: string }[]> {
  const client = await getUncachableOneDriveClient();
  
  const endpoint = folderId 
    ? `/me/drive/items/${folderId}/children`
    : '/me/drive/root/children';
  
  const response = await client.api(endpoint).get();
  
  return response.value
    .filter((item: any) => item.folder)
    .map((folder: any) => ({
      id: folder.id,
      name: folder.name,
      path: folder.parentReference?.path ? `${folder.parentReference.path}/${folder.name}` : `/${folder.name}`
    }));
}

// Scan files from OneDrive
export async function scanOneDriveFiles(folderId?: string): Promise<any[]> {
  const client = await getUncachableOneDriveClient();
  
  // Get all files recursively
  const endpoint = folderId 
    ? `/me/drive/items/${folderId}/children`
    : '/me/drive/root/children';
  
  const response = await client.api(endpoint).get();
  
  const files: any[] = [];
  
  for (const item of response.value) {
    if (item.file) {
      const name = item.name;
      const extension = name.includes('.') ? name.split('.').pop()?.toLowerCase() || '' : '';
      const type = getFileType(extension);
      
      files.push({
        name,
        path: `onedrive://${item.parentReference?.path || ''}/${name}`,
        size: item.size || 0,
        type,
        extension,
        lastModified: item.lastModifiedDateTime || new Date().toISOString(),
        lastAccessed: item.lastModifiedDateTime || new Date().toISOString(),
        previewUrl: item.webUrl || null,
        cloudId: item.id,
        cloudSource: 'onedrive' as const
      });
    } else if (item.folder) {
      // Recursively scan subfolders
      try {
        const subFiles = await scanOneDriveFiles(item.id);
        files.push(...subFiles);
      } catch (e) {
        // Skip folders we can't access
      }
    }
  }

  return files;
}

function getFileType(extension: string): string {
  const imageExts = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg', 'ico'];
  const videoExts = ['mp4', 'avi', 'mov', 'mkv', 'wmv', 'flv', 'webm'];
  const audioExts = ['mp3', 'wav', 'ogg', 'flac', 'aac', 'm4a'];
  const docExts = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'rtf'];
  const archiveExts = ['zip', 'rar', '7z', 'tar', 'gz'];
  
  if (imageExts.includes(extension)) return 'image';
  if (videoExts.includes(extension)) return 'video';
  if (audioExts.includes(extension)) return 'audio';
  if (docExts.includes(extension)) return 'document';
  if (archiveExts.includes(extension)) return 'archive';
  return 'other';
}
