import type { Express, RequestHandler } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertScanSessionSchema, insertScannedFileSchema, actionTypes, userRoles } from "@shared/schema";
import { z } from "zod";
import { isAuthenticated } from "./replit_integrations/auth";
import { listGoogleDriveFolders, scanGoogleDriveFiles } from "./integrations/google-drive";
import { listDropboxFolders, scanDropboxFiles } from "./integrations/dropbox";
import { listOneDriveFolders, scanOneDriveFiles } from "./integrations/onedrive";

// Admin-only middleware
const isAdmin: RequestHandler = async (req: any, res, next) => {
  try {
    const userId = req.user?.claims?.sub;
    if (!userId) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    
    const user = await storage.getUser(userId);
    if (!user || user.role !== "admin") {
      return res.status(403).json({ error: "Admin access required" });
    }
    
    next();
  } catch (error) {
    res.status(500).json({ error: "Failed to verify admin status" });
  }
};

// Schema for bulk file insertion
const bulkFilesSchema = z.object({
  files: z.array(insertScannedFileSchema)
});

// Schema for file action
const fileActionSchema = z.object({
  fileIds: z.array(z.string()).min(1, "At least one file ID is required"),
  actionType: z.enum(actionTypes),
  sessionId: z.string(),
  destination: z.string().optional()
});

// Schema for bulk selection
const bulkSelectSchema = z.object({
  fileIds: z.array(z.string()),
  isSelected: z.boolean()
});

// Schema for updating scan stats
const updateStatsSchema = z.object({
  totalFiles: z.number().int().min(0),
  totalSizeMB: z.number().int().min(0)
});

// Schema for single file selection
const fileSelectionSchema = z.object({
  isSelected: z.boolean()
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // ============ SCAN SESSIONS ============
  
  // Create a new scan session
  app.post("/api/scans", async (req, res) => {
    try {
      const data = insertScanSessionSchema.parse(req.body);
      const session = await storage.createScanSession(data);
      res.json(session);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create scan session" });
    }
  });

  // Get all scan sessions
  app.get("/api/scans", async (req, res) => {
    try {
      const sessions = await storage.getAllScanSessions();
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch scan sessions" });
    }
  });

  // Get a specific scan session
  app.get("/api/scans/:id", async (req, res) => {
    try {
      const session = await storage.getScanSession(req.params.id);
      if (!session) {
        return res.status(404).json({ error: "Scan session not found" });
      }
      res.json(session);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch scan session" });
    }
  });

  // Update scan session stats
  app.patch("/api/scans/:id/stats", async (req, res) => {
    try {
      const { totalFiles, totalSizeMB } = updateStatsSchema.parse(req.body);
      const session = await storage.updateScanSessionStats(req.params.id, totalFiles, totalSizeMB);
      if (!session) {
        return res.status(404).json({ error: "Scan session not found" });
      }
      res.json(session);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to update scan session" });
    }
  });

  // ============ SCANNED FILES ============

  // Add files to a scan session
  app.post("/api/scans/:id/files", async (req, res) => {
    try {
      const { files } = bulkFilesSchema.parse(req.body);
      const createdFiles = await storage.createScannedFiles(files);
      
      // Update session stats
      if (createdFiles.length > 0) {
        const totalSizeBytes = createdFiles.reduce((sum, f) => sum + f.size, 0);
        const totalSizeMB = Math.round(totalSizeBytes / (1024 * 1024));
        await storage.updateScanSessionStats(req.params.id, createdFiles.length, totalSizeMB);
      }
      
      res.json(createdFiles);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to add files to scan" });
    }
  });

  // Get files for a scan session
  app.get("/api/scans/:id/files", async (req, res) => {
    try {
      const files = await storage.getFilesBySession(req.params.id);
      res.json(files);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch files" });
    }
  });

  // Update file selection
  app.patch("/api/files/:id/select", async (req, res) => {
    try {
      const { isSelected } = fileSelectionSchema.parse(req.body);
      const file = await storage.updateFileSelection(req.params.id, isSelected);
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }
      res.json(file);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to update file selection" });
    }
  });

  // Bulk update file selections
  app.patch("/api/files/bulk-select", async (req, res) => {
    try {
      const { fileIds, isSelected } = bulkSelectSchema.parse(req.body);
      await storage.updateFilesSelection(fileIds, isSelected);
      res.json({ success: true });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to update file selections" });
    }
  });

  // ============ FILE ACTIONS ============

  // Perform action on files (backup, archive, delete)
  app.post("/api/files/action", async (req, res) => {
    try {
      const { fileIds, actionType, sessionId } = fileActionSchema.parse(req.body);

      // Get file details for the action log
      const allFiles = await storage.getFilesBySession(sessionId);
      const targetFiles = allFiles.filter(f => fileIds.includes(f.id));
      
      if (targetFiles.length === 0) {
        return res.status(404).json({ error: "No matching files found for the provided IDs" });
      }
      
      // Create action records
      const actions = targetFiles.map(file => ({
        fileId: file.id,
        sessionId,
        actionType,
        fileName: file.name,
        filePath: file.path,
        fileSize: file.size,
        success: true
      }));
      
      const createdActions = await storage.createFileActions(actions);
      
      // Mark files as actioned
      await storage.markFilesActioned(fileIds, actionType);
      
      res.json({ 
        success: true, 
        actions: createdActions,
        message: `Successfully ${actionType}d ${fileIds.length} file(s)` 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to perform action on files" });
    }
  });

  // Get action history
  app.get("/api/actions", async (req, res) => {
    try {
      const actions = await storage.getAllActions();
      res.json(actions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch actions" });
    }
  });

  // Get actions for a specific session
  app.get("/api/scans/:id/actions", async (req, res) => {
    try {
      const actions = await storage.getActionsBySession(req.params.id);
      res.json(actions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch session actions" });
    }
  });

  // ============ ADMIN ROUTES ============

  // Get all users (admin only)
  app.get("/api/admin/users", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const allUsers = await storage.getAllUsers();
      res.json(allUsers);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch users" });
    }
  });

  // Update user role (admin only)
  app.patch("/api/admin/users/:id/role", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const { role } = z.object({ role: z.enum(userRoles) }).parse(req.body);
      const user = await storage.updateUserRole(req.params.id, role);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to update user role" });
    }
  });

  // ============ CLOUD STORAGE ROUTES ============

  // Get Google Drive folders (authenticated)
  app.get("/api/cloud/google-drive/folders", isAuthenticated, async (req, res) => {
    try {
      const folders = await listGoogleDriveFolders();
      res.json(folders);
    } catch (error: any) {
      console.error("Google Drive folders error:", error);
      if (error.message?.includes('token') || error.message?.includes('auth')) {
        res.status(401).json({ error: "Google Drive authorization expired. Please reconnect." });
      } else {
        res.status(500).json({ error: error.message || "Failed to fetch Google Drive folders" });
      }
    }
  });

  // Scan Google Drive files (authenticated)
  app.get("/api/cloud/google-drive/scan", isAuthenticated, async (req, res) => {
    try {
      const folderId = typeof req.query.folderId === 'string' ? req.query.folderId : undefined;
      const files = await scanGoogleDriveFiles(folderId);
      res.json(files);
    } catch (error: any) {
      console.error("Google Drive scan error:", error);
      if (error.message?.includes('token') || error.message?.includes('auth')) {
        res.status(401).json({ error: "Google Drive authorization expired. Please reconnect." });
      } else {
        res.status(500).json({ error: error.message || "Failed to scan Google Drive files" });
      }
    }
  });

  // Check if Google Drive is connected (public to show connection status)
  app.get("/api/cloud/google-drive/status", async (req, res) => {
    try {
      await listGoogleDriveFolders();
      res.json({ connected: true });
    } catch (error) {
      res.json({ connected: false });
    }
  });

  // ============ DROPBOX ROUTES ============

  // Check Dropbox connection status
  app.get("/api/cloud/dropbox/status", async (req, res) => {
    try {
      await listDropboxFolders();
      res.json({ connected: true });
    } catch (error) {
      res.json({ connected: false });
    }
  });

  // Scan Dropbox files (authenticated)
  app.get("/api/cloud/dropbox/scan", isAuthenticated, async (req, res) => {
    try {
      const path = typeof req.query.path === 'string' ? req.query.path : '';
      const files = await scanDropboxFiles(path);
      res.json(files);
    } catch (error: any) {
      console.error("Dropbox scan error:", error);
      if (error.message?.includes('token') || error.message?.includes('auth') || error.message?.includes('not connected')) {
        res.status(401).json({ error: "Dropbox authorization expired. Please reconnect." });
      } else {
        res.status(500).json({ error: error.message || "Failed to scan Dropbox files" });
      }
    }
  });

  // ============ ONEDRIVE ROUTES ============

  // Check OneDrive connection status
  app.get("/api/cloud/onedrive/status", async (req, res) => {
    try {
      await listOneDriveFolders();
      res.json({ connected: true });
    } catch (error) {
      res.json({ connected: false });
    }
  });

  // Scan OneDrive files (authenticated)
  app.get("/api/cloud/onedrive/scan", isAuthenticated, async (req, res) => {
    try {
      const folderId = typeof req.query.folderId === 'string' ? req.query.folderId : undefined;
      const files = await scanOneDriveFiles(folderId);
      res.json(files);
    } catch (error: any) {
      console.error("OneDrive scan error:", error);
      if (error.message?.includes('token') || error.message?.includes('auth') || error.message?.includes('not connected')) {
        res.status(401).json({ error: "OneDrive authorization expired. Please reconnect." });
      } else {
        res.status(500).json({ error: error.message || "Failed to scan OneDrive files" });
      }
    }
  });

  return httpServer;
}
