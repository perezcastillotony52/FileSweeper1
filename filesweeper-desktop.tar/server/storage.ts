import { 
  type User,
  type ScanSession, type InsertScanSession,
  type ScannedFile, type InsertScannedFile,
  type FileAction, type InsertFileAction,
  users, scanSessions, scannedFiles, fileActions
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, inArray } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  updateUserRole(userId: string, role: string): Promise<User | undefined>;

  // Scan Sessions
  createScanSession(session: InsertScanSession): Promise<ScanSession>;
  getScanSession(id: string): Promise<ScanSession | undefined>;
  getAllScanSessions(): Promise<ScanSession[]>;
  updateScanSessionStats(id: string, totalFiles: number, totalSizeMB: number): Promise<ScanSession | undefined>;

  // Scanned Files
  createScannedFiles(files: InsertScannedFile[]): Promise<ScannedFile[]>;
  getFilesBySession(sessionId: string): Promise<ScannedFile[]>;
  updateFileSelection(fileId: string, isSelected: boolean): Promise<ScannedFile | undefined>;
  updateFilesSelection(fileIds: string[], isSelected: boolean): Promise<void>;
  markFilesActioned(fileIds: string[], actionType: string): Promise<void>;

  // File Actions
  createFileAction(action: InsertFileAction): Promise<FileAction>;
  createFileActions(actions: InsertFileAction[]): Promise<FileAction[]>;
  getActionsBySession(sessionId: string): Promise<FileAction[]>;
  getAllActions(): Promise<FileAction[]>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return db.select().from(users).orderBy(desc(users.createdAt));
  }

  async updateUserRole(userId: string, role: string): Promise<User | undefined> {
    const [updated] = await db
      .update(users)
      .set({ role, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return updated;
  }

  // Scan Sessions
  async createScanSession(session: InsertScanSession): Promise<ScanSession> {
    const [created] = await db.insert(scanSessions).values(session).returning();
    return created;
  }

  async getScanSession(id: string): Promise<ScanSession | undefined> {
    const [session] = await db.select().from(scanSessions).where(eq(scanSessions.id, id));
    return session;
  }

  async getAllScanSessions(): Promise<ScanSession[]> {
    return db.select().from(scanSessions).orderBy(desc(scanSessions.createdAt));
  }

  async updateScanSessionStats(id: string, totalFiles: number, totalSizeMB: number): Promise<ScanSession | undefined> {
    const [updated] = await db
      .update(scanSessions)
      .set({ totalFiles, totalSizeMB })
      .where(eq(scanSessions.id, id))
      .returning();
    return updated;
  }

  // Scanned Files
  async createScannedFiles(files: InsertScannedFile[]): Promise<ScannedFile[]> {
    if (files.length === 0) return [];
    return db.insert(scannedFiles).values(files).returning();
  }

  async getFilesBySession(sessionId: string): Promise<ScannedFile[]> {
    return db.select().from(scannedFiles).where(eq(scannedFiles.sessionId, sessionId));
  }

  async updateFileSelection(fileId: string, isSelected: boolean): Promise<ScannedFile | undefined> {
    const [updated] = await db
      .update(scannedFiles)
      .set({ isSelected })
      .where(eq(scannedFiles.id, fileId))
      .returning();
    return updated;
  }

  async updateFilesSelection(fileIds: string[], isSelected: boolean): Promise<void> {
    if (fileIds.length === 0) return;
    await db
      .update(scannedFiles)
      .set({ isSelected })
      .where(inArray(scannedFiles.id, fileIds));
  }

  async markFilesActioned(fileIds: string[], actionType: string): Promise<void> {
    if (fileIds.length === 0) return;
    await db
      .update(scannedFiles)
      .set({ actionTaken: actionType })
      .where(inArray(scannedFiles.id, fileIds));
  }

  // File Actions
  async createFileAction(action: InsertFileAction): Promise<FileAction> {
    const [created] = await db.insert(fileActions).values(action).returning();
    return created;
  }

  async createFileActions(actions: InsertFileAction[]): Promise<FileAction[]> {
    if (actions.length === 0) return [];
    return db.insert(fileActions).values(actions).returning();
  }

  async getActionsBySession(sessionId: string): Promise<FileAction[]> {
    return db.select().from(fileActions).where(eq(fileActions.sessionId, sessionId)).orderBy(desc(fileActions.createdAt));
  }

  async getAllActions(): Promise<FileAction[]> {
    return db.select().from(fileActions).orderBy(desc(fileActions.createdAt));
  }
}

export const storage = new DatabaseStorage();
