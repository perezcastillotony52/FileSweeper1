const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  minimizeWindow: () => ipcRenderer.invoke('minimize-window'),
  maximizeWindow: () => ipcRenderer.invoke('maximize-window'),
  closeWindow: () => ipcRenderer.invoke('close-window'),
  
  selectDirectory: () => ipcRenderer.invoke('select-directory'),
  scanDirectory: (dirPath, options) => ipcRenderer.invoke('scan-directory', dirPath, options),
  
  deleteFiles: (filePaths, toRecycleBin) => ipcRenderer.invoke('delete-files', filePaths, toRecycleBin),
  copyFiles: (filePaths, destination) => ipcRenderer.invoke('copy-files', filePaths, destination),
  moveFiles: (filePaths, destination) => ipcRenderer.invoke('move-files', filePaths, destination),
  
  getDrives: () => ipcRenderer.invoke('get-drives'),
  
  isElectron: true,
});
