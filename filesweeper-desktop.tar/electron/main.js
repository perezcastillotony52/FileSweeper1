const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');

let mainWindow;
const isDev = process.env.NODE_ENV === 'development';
const appUrl = isDev ? 'http://localhost:5000' : `file://${path.join(__dirname, '../dist/public/index.html')}`;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1024,
    minHeight: 700,
    frame: true,
    icon: path.join(__dirname, '../public/favicon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false,
    },
  });

  if (isDev) {
    mainWindow.loadURL('http://localhost:5000');
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(path.join(__dirname, '../dist/public/index.html'));
  }

  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (!url.startsWith(appUrl) && !url.startsWith('http://localhost:5000')) {
      event.preventDefault();
      shell.openExternal(url);
    }
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

ipcMain.handle('minimize-window', () => {
  mainWindow?.minimize();
});

ipcMain.handle('maximize-window', () => {
  if (mainWindow?.isMaximized()) {
    mainWindow.unmaximize();
  } else {
    mainWindow?.maximize();
  }
});

ipcMain.handle('close-window', () => {
  mainWindow?.close();
});

ipcMain.handle('select-directory', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openDirectory'],
  });
  return result.filePaths[0] || null;
});

function isValidPath(inputPath) {
  if (typeof inputPath !== 'string' || inputPath.length === 0) return false;
  const resolved = path.resolve(inputPath);
  const normalized = path.normalize(inputPath);
  if (normalized.includes('..')) return false;
  return true;
}

ipcMain.handle('scan-directory', async (event, dirPath, options) => {
  if (!isValidPath(dirPath)) {
    throw new Error('Invalid directory path');
  }
  
  const { minAgeDays = 30, minSizeMB = 0, fileTypes = [] } = options;
  const files = [];
  const now = Date.now();
  const minAgeMs = minAgeDays * 24 * 60 * 60 * 1000;
  const minSizeBytes = minSizeMB * 1024 * 1024;

  const fileTypeExtensions = {
    image: ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.svg', '.ico', '.tiff'],
    video: ['.mp4', '.avi', '.mov', '.mkv', '.wmv', '.flv', '.webm', '.m4v'],
    document: ['.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.txt', '.rtf', '.odt'],
    archive: ['.zip', '.rar', '.7z', '.tar', '.gz', '.bz2'],
    audio: ['.mp3', '.wav', '.flac', '.aac', '.ogg', '.wma', '.m4a'],
  };

  function getFileType(ext) {
    ext = ext.toLowerCase();
    for (const [type, extensions] of Object.entries(fileTypeExtensions)) {
      if (extensions.includes(ext)) return type;
    }
    return 'other';
  }

  function scanDir(currentPath, depth = 0) {
    if (depth > 10) return;
    
    try {
      const entries = fs.readdirSync(currentPath, { withFileTypes: true });
      
      for (const entry of entries) {
        const fullPath = path.join(currentPath, entry.name);
        
        try {
          if (entry.isDirectory()) {
            if (!entry.name.startsWith('.') && entry.name !== 'node_modules') {
              scanDir(fullPath, depth + 1);
            }
          } else if (entry.isFile()) {
            const stats = fs.statSync(fullPath);
            const age = now - stats.mtimeMs;
            const ext = path.extname(entry.name);
            const type = getFileType(ext);
            
            if (age >= minAgeMs && stats.size >= minSizeBytes) {
              if (fileTypes.length === 0 || fileTypes.includes(type)) {
                files.push({
                  id: Buffer.from(fullPath).toString('base64'),
                  name: entry.name,
                  path: fullPath,
                  size: stats.size,
                  type: type,
                  extension: ext.slice(1) || 'unknown',
                  lastModified: stats.mtime.toISOString(),
                  createdAt: stats.birthtime.toISOString(),
                });
              }
            }
          }
        } catch (err) {
          console.log(`Cannot access: ${fullPath}`);
        }
      }
    } catch (err) {
      console.log(`Cannot read directory: ${currentPath}`);
    }
  }

  scanDir(dirPath);
  return files;
});

ipcMain.handle('delete-files', async (event, filePaths, toRecycleBin = true) => {
  const results = [];
  
  for (const filePath of filePaths) {
    if (!isValidPath(filePath)) {
      results.push({ path: filePath, success: false, error: 'Invalid path' });
      continue;
    }
    try {
      if (toRecycleBin) {
        await shell.trashItem(filePath);
      } else {
        fs.unlinkSync(filePath);
      }
      results.push({ path: filePath, success: true });
    } catch (err) {
      results.push({ path: filePath, success: false, error: err.message });
    }
  }
  
  return results;
});

ipcMain.handle('copy-files', async (event, filePaths, destination) => {
  if (!isValidPath(destination)) {
    throw new Error('Invalid destination path');
  }
  
  const results = [];
  
  if (!fs.existsSync(destination)) {
    fs.mkdirSync(destination, { recursive: true });
  }
  
  for (const filePath of filePaths) {
    if (!isValidPath(filePath)) {
      results.push({ path: filePath, success: false, error: 'Invalid path' });
      continue;
    }
    try {
      const fileName = path.basename(filePath);
      const destPath = path.join(destination, fileName);
      fs.copyFileSync(filePath, destPath);
      results.push({ path: filePath, success: true, destination: destPath });
    } catch (err) {
      results.push({ path: filePath, success: false, error: err.message });
    }
  }
  
  return results;
});

ipcMain.handle('move-files', async (event, filePaths, destination) => {
  if (!isValidPath(destination)) {
    throw new Error('Invalid destination path');
  }
  
  const results = [];
  
  if (!fs.existsSync(destination)) {
    fs.mkdirSync(destination, { recursive: true });
  }
  
  for (const filePath of filePaths) {
    if (!isValidPath(filePath)) {
      results.push({ path: filePath, success: false, error: 'Invalid path' });
      continue;
    }
    try {
      const fileName = path.basename(filePath);
      const destPath = path.join(destination, fileName);
      fs.renameSync(filePath, destPath);
      results.push({ path: filePath, success: true, destination: destPath });
    } catch (err) {
      results.push({ path: filePath, success: false, error: err.message });
    }
  }
  
  return results;
});

ipcMain.handle('get-drives', async () => {
  if (process.platform === 'win32') {
    const drives = [];
    for (let i = 65; i <= 90; i++) {
      const drive = String.fromCharCode(i) + ':\\';
      try {
        fs.accessSync(drive);
        drives.push(drive);
      } catch (err) {}
    }
    return drives;
  }
  return ['/'];
});
